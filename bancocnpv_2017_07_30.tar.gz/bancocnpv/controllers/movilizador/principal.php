<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Principal extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('usuarios_model');
        $this->load->model('general_model');
        $this->load->model('login_model');
		$this->load->model('perfil_model');
        $this->load->helper(array('url', 'form'));
        $this->load->library('session');
		$this->load->model('convocatorias_model');
        
       /*  if (!($this->session->userdata('language'))) {
            $this->session->set_userdata('language', 'spanish');
        }        
        $user_language = $this->session->userdata('language');        
        $this->lang->load('rtc_' . $user_language, $user_language);*/
    }

    public function index() {
		//if($this->session->userdata('ciudad') != ''){
			$datos["ciudades"] = $this -> convocatorias_model -> ciudades_coordinador($this->session->userdata('email'));	
			//$datos["conv_abiertas"] = $this -> convocatorias_model -> convocatorias_coor_abiertas($this->session->userdata('ciudad'));			
			//$datos["conv_cerradas"] = $this -> convocatorias_model -> convocatorias_coor_cerradas($this->session->userdata('ciudad'));
			$datos['departamentos'] = $this->login_model->departamentos();
			$datos['roles'] = $this->login_model->roles(); 
			$datos['programa'] = $this->login_model->programa();
			$datos["contenido"] = "movilizador/inscribir";
			$this->load->view('plantilla', $datos);
		//}else{
		//	$this -> session -> set_flashdata('retornoError', 'El usuario no tiene asociada completa la informaci&oacute;n');
		//	redirect(base_url(), 'refresh');
		//}
    }
    
    public function cargaMuni()
    {
    	if($this->input->post('departamentoAplica'))
    	{
    		$departamentoAplica = $this->input->post('departamentoAplica');
    		$munisAplica = $this->perfil_model->municipios($departamentoAplica);
    			
    		if(count($munisAplica) > 0){
    			?>
    				<option value="">Seleccione...</option>
    				<?php
    				foreach($munisAplica as $fila)
    				{
    				?>
    					<option value="<?=$fila -> id_mpio ?>"><?=$fila -> nom_mpio ?></option>
    				<?php
    				}
    			}else{
    				?>
    				<option value="">No existen municipios asociados...</option>
    				<?php
    			}
    			
    		}
    	}
	
	public function verificarDoc($id_convocatoria, $id_conv_insc) {
        
		if($this->session->userdata('ciudad') != ''){
			
			$datos['info_conv'] = $this->convocatorias_model->infoConvMun($id_convocatoria, $id_conv_insc);
			$datos['info_usuarios'] = $this->convocatorias_model->personasInscritas($id_convocatoria, $id_conv_insc);
			$datos['info_requ'] = $this->convocatorias_model->requisitosInscritosMun($id_convocatoria, $id_conv_insc);
			$datos['info_requ2'] = $this->convocatorias_model->requisitosInscritos2($id_convocatoria);
			$datos['info_convocatoriaEsp'] = $this->convocatorias_model->info_convocatoriaEsp($id_convocatoria);
			$datos['id_convocatoria'] = $id_convocatoria;
			$datos['id_conv_insc'] = $id_conv_insc;
			
			$datos["contenido"] = "movilizador/inscritos";
			$this->load->view('plantilla', $datos);
		}else{
			$this -> session -> sess_destroy();
			$this -> session -> set_flashdata('retornoError', 'El usuario no tiene asociada completa la informaci&oacute;n');
			redirect(base_url(), 'refresh');
		}
    }
	
	public function actualizarDoc($id_convocatoria, $id_conv_insc, $id_usuario){
		
			
		$documentos = $_REQUEST['documentos'];
		$observaciones = utf8_encode($_REQUEST['observaciones']);

		$datosUsuario = $this->convocatorias_model->datosUsuario($id_usuario);
		$datosConvocatoria = $this->convocatorias_model->info_convocatoria($id_convocatoria);
		$ultimaAplicacion = $this->convocatorias_model->ultima_aplicacion($id_usuario,$id_convocatoria,$id_conv_insc); 
		
		$usuarioDocumentos = $this->convocatorias_model->actualizarDocumentos($id_convocatoria, $id_conv_insc, $id_usuario, $documentos, $observaciones,$ultimaAplicacion[0]->id_usu_conv);
		
		if($usuarioDocumentos){
			
			if($documentos == 3){
				
				$usuarioLiberar = $this->convocatorias_model->liberarUsuarioConv($id_usuario, $id_convocatoria, $id_conv_insc);
				
				$this -> load -> library('My_PHPMailer');
	
				$this -> load -> library('email');
				$configMail = array('protocol' => 'smtp', 'smtp_host' => 'mail.dane.gov.co', 'smtp_port' => 25, 'smtp_user' => 'aplicaciones@dane.gov.co', 'smtp_pass' => '0u67UtapW3v', 'mailtype' => 'html', 'charset' => 'utf-8', 'newline' => "\r\n");
				//cargamos la configuración para enviar mail
				$this -> email -> initialize($configMail);
	
				$this -> email -> from('aplicaciones@dane.gov.co', 'Banco Hojas de Vida');
				$this -> email -> to($datosUsuario[0]->usuario);
				//$this -> email -> to('jonandres.c@gmail.com');
				//$this -> email -> bcc('esanchez1988@gmail.com');
				$this -> email -> subject('Información importante convocatoria DANE');
				
				$html = '
					  <p>Estimado Usuario</p>				
		              <p>
		                Revisados los documentos que usted anexo a la plataforma del DANE - Hojas de Vida frente al
						perfil requerido para la convocatoria a la que se postuló '.$datosConvocatoria[0]->nombre_inv.' - '.$datosConvocatoria[0]->nombre_rol_inv.', nos						
						permitimos informarle que no ha sido elegido para continuar en el proceso, toda vez que según lo						
						manifiesta la Sede y Subsede en la observación de la verificación de requisitos mínimos la cual fue						
						"'.$observaciones.'"
					  </p>						
					  <p>
						Lo invitamos a seguir revisando la plataforma para que aplique a las distintas convocatorias que el	DANE ofrece.
					  </p>';
			
				$this -> email -> message($html);
				if ($this -> email -> send()) {
					
				}
			}

			$this -> session -> set_flashdata('retornoExito', 'La actualizaci&oacute;n se realizo con exito');
			redirect(base_url('movilizador/principal/verificarDoc/'.$id_convocatoria.'/'.$id_conv_insc), 'refresh');
		}else{
			$this->session->set_flashdata('retornoError', 'Error al actualizar el registro, por favor contacte al administrador');
            redirect(base_url('movilizador/principal/verificarDoc/'.$id_convocatoria.'/'.$id_conv_insc), 'refresh');
		}
	}
	
	public function cambiaCiudad(){

		if($_REQUEST['ciudad'] != ''){
			$this->session->set_userdata('ciudad', $_REQUEST['ciudad']);			
		}
	}
	
	public function liberarUsuarios ($datos, $id_convocatoria, $id_conv_insc) {
		
		$usuarios = explode('-',$datos);
		
		for($u=0;$u<count($usuarios);$u++){
			if($usuarios[$u] != ''){
				$usuarioLibres = $this->convocatorias_model->liberarUsuario($usuarios[$u]);
			}
		}
		
		$this -> session -> set_flashdata('retornoExito', 'Se liberaron los usuarios que no cumplen con los requisitos');
		redirect(base_url('movilizador/principal/verificarDoc/'.$id_convocatoria.'/'.$id_conv_insc), 'refresh');
	}
	
	public function guardarUsuario() {

		$resultadoUserVali = $this->usuarios_model->validarUsuarioIdentificacion($_REQUEST['tipo_iden'], $_REQUEST['inputNumeIden']);
		
		if($resultadoUserVali == '')
		{
			$resultadoEmailVali = $this->usuarios_model->validarUsuarioCorreo($_REQUEST['inputEmail']);
				
			if($resultadoEmailVali == '')
			{
				$cadena_aleatoria="";
				$codigo_unico="";
				/**********--------DEFINICION DE FORMATO DE FECHAS -------------------------************/
				$fechaExpMov = new DateTime($_REQUEST['fechaExpMov']);
				$fechaExpMov2 = date_format($fechaExpMov, 'Y-m-d');
				$fechaExpMov3 = date_format($fechaExpMov, 'd-m-Y');
				
				$fechaNaciMov = new DateTime($_REQUEST['fechaNaciMov']);
				$fechaNaciMov2 = date_format($fechaNaciMov, 'Y-m-d');
				
				
				$cadena_aleatoria= $this-> generateRandomString();
				$codigo_unico = $_REQUEST['inputNumeIden'].$cadena_aleatoria;
					
				$datosU['tipo_iden'] = $_REQUEST['tipo_iden'];
				$datosU['nume_iden'] = $_REQUEST['inputNumeIden'];
				$datosU['nombres'] = utf8_encode($_REQUEST['inputNombres']);
				$datosU['apellidos'] = utf8_encode($_REQUEST['inputApellidos']);
				$datosU['email2'] = utf8_encode($_REQUEST['inputEmail']);
				$datosU['celular'] = $_REQUEST['celular'];
				$datosU['id_depto'] = $_REQUEST['departamento'];
				$datosU['id_municipio'] = $_REQUEST['municipio'];
				$datosU['telefono'] = $_REQUEST['telefono'];
				$datosU['fecha_naci'] = $fechaNaciMov2;
				$datosU['fecha_expedicion_cedula'] = $fechaExpMov2;
				$datosU['sexo'] = $_REQUEST['sexo'];
				$datosU['codigo_unico'] = $codigo_unico;
				$datosU['estado_hv'] = $_REQUEST['estadohv'];
				$datosU['id_usuario_registra'] = $this->session->userdata('id_usuario');
		
				//Se registra la informacion del usuario, restorna el ID que asigna la BD
				$resultadoID = $this->usuarios_model->insertarUsuario($datosU);
				//$resultadoID = 4;
				if ($resultadoID) {
					$datosRol['id_usuario'] = $resultadoID;
					$datosRol['rol'] = 3;
					$datosRol['estado'] = 'AC';
					$resultadoRol = $this->usuarios_model->insertarRolUsuario($datosRol);
					
					$psswd = str_replace("-","",$fechaExpMov3);
					$datosLogin['usuario_id_usuario'] = $resultadoID;
					$datosLogin['usuario'] = $codigo_unico;
					$datosLogin['clave'] = sha1(md5($psswd));
					$datosLogin['estado'] = 'AC';
					//$datosLogin['estado'] = 'AC';
		
					$resultadoLogin = $this->usuarios_model->insertarDatosLogin($datosLogin);
		
					
					
					$this->session->set_flashdata('retornoExito', '<table border="1" align="center" ><tr><td align="center" colspan="2"><h4>Registro Exitoso</h4></td><tr><td align="center"><h4>El usuario de ingreso es:</h4></td><td align="center" ><h4>'. $codigo_unico .'</h4></td><tr><td align="center"><h4>la clave es:</h4></td><td><h4>'. $psswd . '</h4></td></tr></table>');
					redirect(base_url('movilizador/principal/cargarDocumento/'.$resultadoID), 'refresh');
				}else{
					$this->session->set_flashdata('retornoError', 'Ocurrio un error al intentar guardar el registro.');
					redirect(base_url('movilizador/principal/'), 'refresh');
				}
			}else{
				$this->session->set_flashdata('retornoError', 'El correo electr&oacute;nico ya se encuentra registrado.');
				redirect(base_url('movilizador/principal/'), 'refresh');
			}
		}else {
			$this->session->set_flashdata('retornoError', 'El usuario ya se encuentra registrado.');
			redirect(base_url('movilizador/principal/'), 'refresh');
		}
	}
	
	public function cargarDocumento($resultadoID) {
		
		$datos["contenido"] = "movilizador/cargarDocumento";
		$this->load->view('plantilla', $datos); 
	}
	
	function generateRandomString($length = 4) {
		return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, $length);
	}
	
	public function cargaArchivo()
	{
		//var_dump($_FILES);exit;
	
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'txt';
		$config['max_size'] = '80000'; 
		$config['file_name'] = "sincronizar_".$this->session->userdata('id_usuario')."_".time();
	
		$this->load->library('upload', $config);
	
		if (!$this->upload->do_upload('doc_sincronizacion')) { 
			//echo "Ingreso1";exit;				
			$error = array('error' => $this->upload->display_errors());
			$this->session->set_flashdata('retornoError', 'Ocurrio un problema al intentar subir el archivo, recuerde que debe subir archivos TXT');
			redirect(base_url('movilizador/principal/cargarArchivo'), 'refresh');
			exit;
		} else {
			
			$ruta = "/home1/home/dimpe/bancohvcnpv/uploads/";
			$ruta_final = $ruta.$config['file_name'].".txt";
			//$ruta_final = $ruta."sincronizar_1_1498583858.txt";
			
			$file = fopen($ruta_final, "r");
			
			while(!feof($file)) {
				$linea_codificada = fgets($file);
				$linea_decodificada = base64_decode($linea_codificada);
			}
			$array_insert=explode(");", $linea_decodificada);  
			//var_dump($array_insert);echo count($array_insert);exit; 
			fclose($file);
			
			for($i=0;$i<(count($array_insert)-1);$i++){
				$resultadoinsert = $this->perfil_model->ejecutaSinc($array_insert[$i]);
			}

			//$actualizar_usuarios = $this->perfil_model->ActualizarUsuarios_sincronizados($this->session->userdata('id_usuario'));
			
			//$this->session->set_flashdata('retornoExito', 'Se sincronizo correctamente todos los datos');
			//redirect(base_url('movilizador/principal/cargarArchivo'), 'refresh');
			//exit;
			
		}
	
		
	}
	
	public function cargaArchivobd()
	{
		//var_dump($_FILES);exit;
	
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'pdf';
		$config['max_size'] = '80000';
		$config['file_name'] = "archivo_".$this->session->userdata('id_usuario')."_".time();
		
		
		/*$archivo = $_FILES["archivo"]["tmp_name"];
		$size = $_FILES["archivo"]["size"];
		$tipo = $_FILES["archivo"]["type"];
		$titulo = $_FILES["archivo"]["name"];
		$nombre = $_POST['nombre']; 
	*/
		$this->load->library('upload', $config);
	
		if (!$this->upload->do_upload('doc_sincronizacion')) {
			echo "Ingreso1";exit;
			$error = array('error' => $this->upload->display_errors());
			$this->session->set_flashdata('retornoError', 'Ocurrio un problema al intentar subir el archivo, recuerde que debe subir archivos TXT');
			redirect(base_url('movilizador/principal/cargarArchivo'), 'refresh');
			exit;
		} else {
				$foto=mysql_real_escape_string(file_get_contents($_FILES["doc_sincronizacion"]["tmp_name"]));
			$ruta = "/home1/home/dimpe/bancohvcnpv/uploads/";
			$ruta_final = $ruta.$config['file_name'].".pdf";
			$nombre_archivo= $config['file_name'].".pdf";
			//$ruta_final = $ruta."sincronizar_1_1498583858.txt";
				
			
			$qry = "INSERT INTO archivos_cnpv (ruta, nombre, fecha, archivo_final) VALUES ('$ruta_final', '$nombre_archivo',now(), '$foto')";
			//echo $qry;exit;
			$resultadoinsert = $this->perfil_model->ejecutaSinc2($qry);
		}
	
	
	}

}
