<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Sincronizar extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('usuarios_model');
        $this->load->model('general_model');
        $this->load->model('login_model');
        $this->load->model('usuarios_model');
        $this->load->model('convocatorias_model');
        $this->load->model('perfil_model');
        $this->load->helper(array('url', 'form', 'html'));
        $this->load->library('session');
		
    	if (!($this -> session -> userdata('language'))) {
        	$this -> session -> set_userdata('language', 'spanish');
        }
           
    }

    public function index() {
        $datos["contenido"] = "movilizador/sincronizar";
        $this->load->view('plantilla', $datos);
    }
    
    public function exportarArchivo() {
    
    	$sincronizado = trim($this->input->post('sincronizado'));
    	
    	$fecha = date("Y-m-d H:i:s");
    	$downloadfile = "archivo_sincronizacion_";
    	 
    	$nombre_archivo =$fecha.$downloadfile.".txt";
    	
    	$ruta = "/home1/home/dimpe/bancohvcnpv_offline/uploads/";
    	$ruta_final = $ruta.$nombre_archivo;
    	
    	$file = fopen($ruta_final, "a+");
    	
    	$consulta_usuarios = $this->usuarios_model->usuarios_sincronizar();
    	$consulta_formacion = $this->usuarios_model->formacion_sincronizar();
    	$consulta_experiencia = $this->usuarios_model->experiencia_sincronizar();
    	$consulta_rolusuario = $this->usuarios_model->rolusuario_sincronizar();
    	
    	$total_usuarios = count($consulta_usuarios);
    	$total_formacion = count($consulta_formacion);
    	$total_experiencia = count($consulta_experiencia);
    	$total_rolusuario = count($consulta_rolusuario);
    	
    	$txt="";
    	$saltoLinea="\r\n";
    	for($i=0;$i<$total_usuarios;$i++){
    		$txt.= base64_encode("INSERT INTO usuario (nombres, apellidos, tipo_iden, nume_iden, fecha_naci, fecha_expedicion_cedula, sexo, id_depto, id_municipio, telefono, celular, email2, codigo_unico, sincronizado, estado_hv, id_usuario_registra)VALUES('".$consulta_usuarios[$i]->nombres."','".$consulta_usuarios[$i]->apellidos."','".$consulta_usuarios[$i]->tipo_iden."', '".$consulta_usuarios[$i]->nume_iden."', '".$consulta_usuarios[$i]->fecha_naci."', '".$consulta_usuarios[$i]->fecha_expedicion_cedula."', '".$consulta_usuarios[$i]->sexo."', '".$consulta_usuarios[$i]->id_depto."', '".$consulta_usuarios[$i]->id_municipio."', '".$consulta_usuarios[$i]->telefono."', '".$consulta_usuarios[$i]->celular."', '".$consulta_usuarios[$i]->email2."', '".$consulta_usuarios[$i]->codigo_unico."', '".$consulta_usuarios[$i]->sincronizado."', '".$consulta_usuarios[$i]->fecha_expedicion_cedula."', '".$consulta_usuarios[$i]->estado_hv."', '".$this->session->userdata('id_usuario')."');".$saltoLinea);
    	}
    	for($i=0;$i<$total_rolusuario;$i++){
    		$txt.= base64_encode("INSERT INTO usuario_rol (id_usuario,rol,estado)VALUES('".$consulta_rolusuario[$i]->id_usuario."','".$consulta_rolusuario[$i]->rol."','".$consulta_rolusuario[$i]->estado."'');".$saltoLinea);
    	}
    	for($i=0;$i<$total_formacion;$i++){
    		//$txt.= base64_encode("INSERT INTO us_experiencia (id_usuario, semestres, id_nivel)VALUES('id_usuario','semestres','id_nivel');".$saltoLinea);
    	 	$txt.= base64_encode("INSERT INTO us_form_acade (id_usuario, semestres, id_nivel)VALUES('".$consulta_formacion[$i]->id_usuario."','".$consulta_formacion[$i]->semestres."','".$consulta_formacion[$i]->id_nivel."');".$saltoLinea);
    	}
    	for($i=0;$i<$total_experiencia;$i++){
    		//$txt.= base64_encode("INSERT INTO us_form_acade (id_usuario, empresa, fecha_ingreso, fecha_retiro)VALUES('id_usuario','empresa','fecha_ingreso', 'fecha_retiro');".$saltoLinea);
    		$txt.= base64_encode("INSERT INTO us_experiencia (id_usuario, empresa, fecha_ingreso, fecha_retiro)VALUES('".$consulta_experiencia[$i]->id_usuario."','".$consulta_experiencia[$i]->empresa."','".$consulta_experiencia[$i]->fecha_ingreso."', '".$consulta_experiencia[$i]->fecha_retiro."');".$saltoLinea);
    	}
    	
    	fwrite($file, $txt, strlen($txt));
    	 
    	fclose($file); 
    	
    	header("Content-disposition: attachment; filename=$nombre_archivo");
    	header("Content-type: MIME");
    	readfile("$ruta_final");
    }
}
