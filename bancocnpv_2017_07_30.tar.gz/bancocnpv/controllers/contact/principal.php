<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Principal extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('usuarios_model');
        $this->load->model('general_model');
        $this->load->model('login_model');
		$this->load->model('perfil_model');
        $this->load->helper(array('url', 'form'));
        $this->load->library('session');
		$this->load->model('convocatorias_model');
        
       /*  if (!($this->session->userdata('language'))) {
            $this->session->set_userdata('language', 'spanish');
        }        
        $user_language = $this->session->userdata('language');        
        $this->lang->load('rtc_' . $user_language, $user_language);*/
    }

    public function index() {
		$datos['campana0'] = $this->perfil_model->campana0(); 
		$datos["contenido"] = "contact/campana0"; 
		$this->load->view('plantilla', $datos);
    }
    
    public function campana0() {
    	$datos['campana0'] = $this->perfil_model->campana0();
    	$datos["contenido"] = "contact/campana0";
    	$this->load->view('plantilla', $datos);
    }
    
    public function campana1() {
    	$datos['campana1'] = $this->perfil_model->campana1();
    	$datos["contenido"] = "contact/campana1"; 
    	$this->load->view('plantilla', $datos);
    }
    
    public function campana2() {
    	$datos['campana2'] = $this->perfil_model->campana2();
    	$datos["contenido"] = "contact/campana2"; 
    	$this->load->view('plantilla', $datos);
    }
    
    public function actualizarCampana0() {
    	$datos['campana0'] = $this->perfil_model->campana0();
    	$datos["contenido"] = "contact/actualizarCampana0";
    	$this->load->view('plantilla', $datos);
    }
    
    public function cargarCampana0() {
    	$this->load->library('PHPExcel.php');
    	$nombre_archivoCarga = "archivoCampana0_" . $this->session->userdata('id_usuario') . "_" . time();
    
    	$config['upload_path'] = './uploads/contactCenter/';
    	$config['allowed_types'] = '*';
    	$config['max_size'] = '10000';
    	$config['file_name'] = $nombre_archivoCarga;
    
    	$this->load->library('upload', $config);
    
    	if (!$this->upload->do_upload('doc_campana0')) {
    
    		$error = array('error' => $this->upload->display_errors());
    		//var_dump($error);
    		$this->session->set_flashdata('retornoError', 'Ocurrio un problema al intentar subir el archivo, recuerde que debe subir archivos Excel');
    		redirect(base_url('contact/principal'), 'refresh');
    		exit;
    	} else {
    		//var_dump($this->PHPExcel_IOFactory);
    		$nombre_archivo = $nombre_archivoCarga. ".xls";
    		$rutaArchivo = './uploads/contactCenter/' . $nombre_archivo;
    
    		$objPHPExcel = PHPExcel_IOFactory::load($rutaArchivo);
    		//var_dump($archivo);
    
    			
    		$archivo = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
    
    		$msj = "";
    		$userPr = 0;
    
    		for ($i = 2; $i <= count($archivo); $i++) {
    			$infoUsuario = $this->convocatorias_model->verifica_usuario($archivo[$i]['E'], $archivo[$i]['F']);
    
    			
    				$datoUsu['nume_iden'] = $archivo[$i]['C'];
    				
    				$idUsuario = $this->usuarios_model->consultarIdUsuario($datoUsu['nume_iden']); 
    				var_dump($idUsuario);exit;
    				if ($idUsuario) {
    					$datosUsuRol['id_usuario'] = $idUsuario;
    					$datosUsuRol['rol'] = 3; 
    					$datosUsuRol['estado'] = 'AC';
    
    					$idUsuarioRol = $this->usuarios_model->insertarRolUsuario($datosUsuRol);
    
    					$datosUsuLogin['usuario_id_usuario'] = $idUsuario;
    					$datosUsuLogin['usuario'] = $archivo[$i]['I'];
    					$datosUsuLogin['clave'] = sha1(md5($archivo[$i]['F']));
    					$datosUsuLogin['estado'] = 'AC';
    
    					$idUsuarioLogin = $this->usuarios_model->insertarDatosLogin($datosUsuLogin);
    				}
    
    				$msj.= "El usuario " . $archivo[$i]['A'] . " " . $archivo[$i]['B'] . " se agreg&oacute; como usuario nuevo<br>";
    				$ret[$userPr]['usuario'] = "El usuario " . $archivo[$i]['A'] . " " . $archivo[$i]['B'] . " se agreg&oacute; como usuario nuevo<br>";
    		
    			//Verificar si el usuario ya se encuentra registrado en esa convocatoria
    			$usuario_conv = $this->convocatorias_model->verificaInvitacionUsuario($idUsuario, $id_conv);
    
    			if (count($usuario_conv) > 0) {
    				$msj.= "El usuario " . $archivo[$i]['A'] . " " . $archivo[$i]['B'] . " ya se encuentra asociado a esta convocatoria<br>";
    				$ret[$userPr]['conv'] = "El usuario " . utf8_decode($archivo[$i]['A']) . " " . utf8_decode($archivo[$i]['B']) . " ya se encuentra asociado a esta convocatoria<br>";
    			} else {
    				//Asociar el usuario a la convocatoria
    
    
    				$ciudadAplica = $this->convocatorias_model->buscarCiudad($archivo[$i]['J']);
    				//echo "<br>Ciudad Archivo: ";var_dump($ciudadAplica);
    				//if(isset($ciudadAplica[0]->id_mpio) && ($ciudadAplica[0]->id_mpio > 0)){
    					
    				if(isset($ciudadAplica[0]->id_mpio) && ($ciudadAplica[0]->id_mpio > 0)){
    					//$ciudadAplicaConv = $this->convocatorias_model->buscarCiudadConvocatoria($id_conv, $ciudadAplica[0]->id_mpio);
    					$munAplica = $ciudadAplica[0]->id_mpio;
    				}else{
    					$munAplica = '11001';
    				}
    
    				$datosInvReg['id_convocatoria'] = $id_conv;
    				$datosInvReg['id_usuario'] = $idUsuario;
    				$datosInvReg['aplico'] = 'NO';
    				$datosInvReg['cumple_req'] = 'NO';
    				$datosInvReg['estado'] = 'AC';
    				$datosInvReg['id_ciudad'] = $munAplica;
    				$registraConv = $this->convocatorias_model->insertarUsuarioInvitacion($datosInvReg);
    
    				$msj.= "El usuario " . utf8_decode($archivo[$i]['A']) . " " . utf8_decode($archivo[$i]['B']) . " se asoci&oacute; correctamente a la convocatoria<br>";
    				$ret[$userPr]['conv'] = "El usuario " . utf8_decode($archivo[$i]['A']) . " " . utf8_decode($archivo[$i]['B']) . " se asoci&oacute; correctamente a la convocatoria<br>";
    
    
    				//echo "<br>Ciudad Aplica: ";var_dump($ciudadAplica);
    				//exit;
    				/*if(count($ciudadAplicaConv)>0){
    				 $datosInvReg['id_convocatoria'] = $id_conv;
    				$datosInvReg['id_usuario'] = $idUsuario;
    				$datosInvReg['aplico'] = 'NO';
    				$datosInvReg['cumple_req'] = 'NO';
    				$datosInvReg['estado'] = 'AC';
    				$datosInvReg['id_ciudad'] = $munAplica;
    				$registraConv = $this->convocatorias_model->insertarUsuarioInvitacion($datosInvReg);
    
    				$msj.= "El usuario " . utf8_decode($archivo[$i]['A']) . " " . utf8_decode($archivo[$i]['B']) . " se asoci&oacute; correctamente a la convocatoria<br>";
    				$ret[$userPr]['conv'] = "El usuario " . utf8_decode($archivo[$i]['A']) . " " . utf8_decode($archivo[$i]['B']) . " se asoci&oacute; correctamente a la convocatoria<br>";
    				}else{
    				$ret[$userPr]['conv'] = "La ciudad asociada no tiene convocatoria vigente<br>";
    				}
    				*/
    				/*
    				}else{
    				$ret[$userPr]['conv'] = "La ciudad asociada no se encuentra registrada<br>";
    				}
    				*/
    
    				}
    				$userPr++;
    				}
    				//exit;
    				$this->session->set_flashdata('retornoTabla', $ret);
    				redirect(base_url('administrador/convocatorias/invitar/' . $id_conv), 'refresh');
    				exit;
    		}
    	}
}
