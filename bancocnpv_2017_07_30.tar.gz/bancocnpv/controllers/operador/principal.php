<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Principal extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('usuarios_model');
        $this->load->model('general_model');
        $this->load->model('login_model');
	$this->load->model('perfil_model');
        $this->load->helper(array('url', 'form'));
        $this->load->library('session');
	$this->load->model('convocatorias_model');
        if(!$this->session->userdata('rol')){
            $this->session->set_flashdata('retornoError', 'Su sesi&oacute;n finalizo');
            redirect(base_url(), 'refresh');
        }
        if(!$this->session->userdata('rol')){
        	$this->session->set_flashdata('retornoError', 'Su sesi&oacute;n finalizo');
        	redirect(base_url(), 'refresh');
        } 
       /*  if (!($this->session->userdata('language'))) {
            $this->session->set_userdata('language', 'spanish');
        }        
        $user_language = $this->session->userdata('language');        
        $this->lang->load('rtc_' . $user_language, $user_language);*/
    }

    public function index() {
               
        $id_usuario = $this->session->userdata('id_usuario');
        $datos["ciudades"] = $this -> usuarios_model -> ciudades_operador($id_usuario);
       
        $datos["contenido"] = "operador/principal";
	$this->load->view('plantilla', $datos);
        
    }
    
  
   
    public function cargaRol()
    {
    	if(trim($this->input->post('operacity')));
        
    	{
    		$operacity = $this->input->post('operacity');
                
                
    		$rolesAplica = $this->usuarios_model->consulta_roles_ciudad($operacity);
    			
    		if(count($rolesAplica) > 0){
    			
    			echo "	<option value=''>Seleccione...</option>";
    			
    				foreach($rolesAplica as $fila)
    				{    			
    					echo "<option value='".$fila -> id_conv_insc. "'>".$fila -> id_convocatoria." - ".$fila -> perfil." - ".$fila -> nombre_rol_inv."</option>";
    			
    				}
    			}else{    			
    				echo "<option value=''>No existen resultados asociados...</option>";    			
    			}
    			
    		}
    }
    
     public function cargaDatosUsuario() {
	
        $id_conv_insc = trim($this->input->post('rol'));
         
         if($id_conv_insc != ''){
                
                $usuarios = $this->usuarios_model->contar_usuarios($id_conv_insc);
                
                if($usuarios[0]->usuarios > 0){
                    
                   $usuariosMax = $this->usuarios_model->usuariosMax($id_conv_insc);                    
                   $usuariosMax[0]->total_personas;
                   
                   $this->generaCandidatos($id_conv_insc, $usuariosMax[0]->total_personas);
                   
                }
                
                $usuariosMax = $this->usuarios_model->usuariosMax($id_conv_insc);                    
                $candidatos = $this->usuarios_model->contar_candidatos($id_conv_insc);                 		
                $elegibles = $this->usuarios_model->contar_elegibles($id_conv_insc);
                $contratados = $this->usuarios_model->contar_contratados($id_conv_insc);
                $abandonaron = $this->usuarios_model->contar_abandonaron($id_conv_insc);
                
                $datos["id_conv_insc"] = $id_conv_insc;   

                $datos["candidatos"] = $candidatos[0]->candidatos;
                $datos["elegibles"] = $elegibles[0]->elegibles;
                $datos["usuariosMax"] = $usuariosMax[0]->total_personas;
                $datos["contratados"] = $contratados[0]->contratados;   
                $datos["abandonaron"] = $abandonaron[0]->abandonaron;   
                 
		$datos["usuarios"] = $this->usuarios_model->consulta_usuario_rol_ciudad($id_conv_insc);
                               
                    if(count($datos["usuarios"]) > 0){
                        $this->load->view('operador/usuariosDatos', $datos);
				//echo $data;
                    }else{
			echo "<center><h2>Sin informaci&oacute;n</h2></center>";
                    }			
			
	}else{
            echo "<center><h2>Sin informaci&oacute;n</h2></center>";
	}
             
   } 
   
    
   
    public function generaCandidatos($id_conv_insc, $usuariosMax){
        
       $usuarios = $this->usuarios_model->usuarios($id_conv_insc);
       
       for ($i=0;count($usuarios);$i++) {
           if($i < $usuariosMax){
               $contrato = 1;
             echo  $this->usuarios_model->usuariosUpdate($usuarios[$i]->id_usu_conv, $contrato);
           }else{
               $contrato = 2;
             echo  $this->usuarios_model->usuariosUpdate($usuarios[$i]->id_usu_conv, $contrato);
           }
       }
        
    }
   
   public function contratar($id_conv_insc, $id_usuario){
        $datos["contenido"] = "operador/contratar";        
        $datos["id_conv_insc"] = $id_conv_insc;  
        $datos["id_usuario"] = $id_usuario;  
        $datos["usuario"] = $this->perfil_model->datos_usuario($id_usuario);        
        
	$this->load->view('plantilla', $datos);
   }
    
   public function guardarContrato(){
       
       if($_REQUEST['contratado'] == 'Si'){


            $id_conv_insc = trim($_REQUEST['id_conv_insc']);
            $id_usuario = trim($_REQUEST['id_usuario']);

             $config['upload_path'] = './uploads/';
             $config['allowed_types'] = 'pdf';
             $config['max_size'] = '1000';
             $config['file_name'] = "docCont_".$id_usuario."_".time();

             $this->load->library('upload', $config);

             if (!$this->upload->do_upload('contrato')) {

                     $error = array('error' => $this->upload->display_errors());

                     $this->session->set_flashdata('retornoError', 'Ocurrio un problema al intentar subir el archivo de contrato, recuerde que debe subir archivos PDF no mayor a 1Mb  <br>');
                     redirect(base_url("operador/principal/contratar/".$id_conv_insc.'/'.$id_usuario), 'refresh');				
                     exit;
             } else {
                     $rutaFinalForma = array('rutaFinal' => $this->upload->data());

                     $datosAr['ruta'] = $rutaFinalForma['rutaFinal']['full_path'];
                     $datosAr['nombre'] = $rutaFinalForma['rutaFinal']['file_name'];
                     $datosAr['fecha'] = date('Y-m-d');
                     $datosAr['tags'] = '';
                     $datosAr['es_publico'] = 0;
                     $datosAr['estado'] = 'AC';

                     $resultadoIDForma = $this->perfil_model->insertarArchivo($datosAr);

                     $docContrato = $resultadoIDForma;
             }
             
       }else{
           $docContrato = 0;
       }      
                     $datosContrato['id_usuario'] = $_REQUEST['id_usuario'];
                     $datosContrato['id_conv_insc'] = $_REQUEST['id_conv_insc'];                
                     $datosContrato['observacionesCont'] = $_REQUEST['observaciones'];
                     $datosContrato['id_docCont'] = $docContrato;
                     $datosContrato['fecha_contratado'] = date('Y-m-d G:i:s');     
                     $datosContrato['id_usuario_operador'] = $this->session->userdata('id_usuario');
                     
                     
                     if($_REQUEST['contratado'] == 'Si'){
                         $datosContrato['contrato'] = 3;
                     }else{
                         $datosContrato['contrato'] = 4;
                     }

                     $resultadoIDContrato = $this->usuarios_model->usuariosContrato($datosContrato);

                     if($resultadoIDContrato)
                     {
                             $this->session->set_flashdata('retornoExito', 'Se agrego la contrataci&oacute;n adecuadamente');
                             redirect(base_url('operador/principal/salida'), 'refresh');
                             exit;
                     }else
                     {
                             $this->session->set_flashdata('retornoError', 'Por favor verifique la informaci&oacute;n, no fue posible agregar el registro');
                               redirect(base_url("operador/principal/contratar/".$_REQUEST['id_conv_insc'].'/'.$_REQUEST['id_usuario']), 'refresh');				
                             exit;
                     }
   }
   
    public function salida(){
          $datos["contenido"] = "operador/salida";        
        
	$this->load->view('plantilla', $datos);
   }
   

}
