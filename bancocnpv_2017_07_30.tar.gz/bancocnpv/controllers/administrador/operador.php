<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Operador extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('usuarios_model');
        $this->load->model('general_model');
        $this->load->model('login_model');
        $this->load->model('usuarios_model');
        $this->load->model('convocatorias_model');
        $this->load->model('perfil_model');
        $this->load->helper(array('url', 'form', 'html'));
        $this->load->library('session');
		
    	if (!($this -> session -> userdata('language'))) {
        	$this -> session -> set_userdata('language', 'spanish');
        }
        
        $user_language = $this -> session -> userdata('language');
        $this -> lang -> load('rtc_' . $user_language, $user_language);
        
        if(!$this->session->userdata('rol')){
        	$this->session->set_flashdata('retornoError', 'Su sesi&oacute;n finalizo');
        	redirect(base_url(), 'refresh');
        }    
        if($this->session->userdata('rol')!=1){
        	redirect(base_url(), 'refresh');
        }           
    }

    public function index() {

        $datos["contenido"] = "administrador/operador_select";
        $this->load->view('plantilla', $datos);	
    }
    
    public function Operadores() {
        $datos["contenido"] = "administrador/operadores";
        
        $datos["operadores"] = $this->usuarios_model->operadores();
        
        $this->load->view('plantilla', $datos);	
    }
    
    public function OperadorC() {
        $datos["contenido"] = "administrador/operador";
        $datos["operadores"] = $this->usuarios_model->operadores();
        $datos["operadorc"] = $this->usuarios_model->operadorC();
        
        $this->load->view('plantilla', $datos);	
    }
    
    public function OperadoresZonas() {
        $datos["contenido"] = "administrador/opera_zonas";
        $datos["operadores"] = $this->usuarios_model->operadores();
        $datos['ciudades_pre'] = $this->convocatorias_model->sedes();
        $datos['ciudadesya'] = $this->usuarios_model->zonasOperador();
        $completo=$datos['ciudades_pre'];
        
        for ($c = 0; $c < count($datos['ciudades_pre']); $c++) {
            for ($a = 0; $a < count($datos['ciudadesya']); $a++) {
                if($datos['ciudades_pre'][$c]->id_mpio  == $datos['ciudadesya'][$a]->id_ciudad){
                unset($completo[$c]);
                }
            }
        }        
        
        $datos['ciudades']= array_values($completo);

        $this->load->view('plantilla', $datos);	
    }
    
    
    public function guardarUsuarioOperador() {
    	 
    	$datosU['tipo_iden'] = $_REQUEST['tipo_iden'];
    	$datosU['celular'] = $_REQUEST['celular'];
    	$datosU['nume_iden'] = $_REQUEST['inputNumeIden'];
    	$datosU['nombres'] = utf8_encode($_REQUEST['inputNombres']);
    	$datosU['apellidos'] = utf8_encode($_REQUEST['inputApellidos']);
    	$datosU['email2'] = utf8_encode($_REQUEST['inputEmail']);
        $datosU['id_operador'] = $_REQUEST['operador'];
        $datosU['id_usuario_registra'] = $this->session->userdata('id_usuario');
        
    	    
    	//Se registra la informacion del usuario, restorna el ID que asigna la BD
    	$resultadoID = $this->usuarios_model->insertarUsuario($datosU);
    	//$resultadoID = 4;
    	if ($resultadoID) {
    		$datosRol['id_usuario'] = $resultadoID;
    		$datosRol['rol'] = 9;
    		$datosRol['estado'] = 'AC';
    		$resultadoRol = $this->usuarios_model->insertarRolUsuario($datosRol);
    
    		$psswd = $_REQUEST['inputNumeIden'];
    		$datosLogin['usuario_id_usuario'] = $resultadoID;
    		$datosLogin['usuario'] = utf8_encode($_REQUEST['inputEmail']);
    		$datosLogin['clave'] = sha1(md5($psswd));
    		$datosLogin['estado'] = 'AC';
    
    		$resultadoLogin = $this->usuarios_model->insertarDatosLogin($datosLogin);
    		
    		$this->session->set_flashdata('retornoExito', 'Registro Exitoso. 
			    			El usuario de ingreso es:'. utf8_encode($_REQUEST['inputEmail']) .'. y la clave es la cedula.');
    		redirect(base_url('administrador/operador/operadorc/'), 'refresh');
    				
    		}else{
    			$this->session->set_flashdata('retornoError', 'Ocurrio un error al intentar guardar el registro.');
    			redirect(base_url('administrador/operador/operadorc/'), 'refresh');
    		}
    }
    
    
    
   public function guardarOperadorP(){
       $datosO['nombre'] = $_REQUEST['operador'];
       $datosO['fecha_creacion'] = date('Y-m-d H:i:s');
       $datosO['estado'] = '1';
       $resultadoOP = $this->usuarios_model->insertarOperador($datosO);
       
       if ($resultadoOP) {
           $this->session->set_flashdata('retornoExito', 'Registro Exitoso.');
    	   redirect(base_url('administrador/operador/operadores/'), 'refresh');
       }else{
           $this->session->set_flashdata('retornoError', 'Ocurrio un error al intentar guardar el registro.');
    	   redirect(base_url('administrador/operador/operadores/'), 'refresh');
       }
       
       
   }
    
    public function editarOperadorP($id_operador){
       $nombre = $_REQUEST['operador'];       
       $resultadoOP = $this->usuarios_model->actualizarOperador($id_operador, $nombre);
       
       if ($resultadoOP) {
           $this->session->set_flashdata('retornoExito', 'Registro Exitoso.');
    	   redirect(base_url('administrador/operador/operadores/'), 'refresh');
       }else{
           $this->session->set_flashdata('retornoError', 'Ocurrio un error al intentar guardar el registro.');
    	   redirect(base_url('administrador/operador/operadores/'), 'refresh');
       }
   }
    
   
   public function editarUsuarioOp($id_usuario){
       $id_operador = $_REQUEST['operador'];       
       $resultadoUSOP = $this->usuarios_model->actualizarUsuarioOp($id_usuario, $id_operador);
       
       if ($resultadoUSOP) {
           $this->session->set_flashdata('retornoExito', 'Registro Exitoso.');
    	   redirect(base_url('administrador/operador/operadorc/'), 'refresh');
       }else{
           $this->session->set_flashdata('retornoError', 'Ocurrio un error al intentar guardar el registro.');
    	   redirect(base_url('administrador/operador/operadorc/'), 'refresh');
       }
   }
   
   public function guardarZonas(){
       $id_operador = $_REQUEST['operador']; 
       
       for ($ciu = 0; $ciu < count($_REQUEST['ciudades']); $ciu++) {
                $datosI['id_operador'] = $id_operador;
                $datosI['id_ciudad'] = $_REQUEST['ciudades'][$ciu];
                $datosI['fecha_creacion'] = date('Y-m-d H:i:s');
                $datosI['estado'] = '1';
                $resultadoConvocatoriaIns = $this->usuarios_model->insertarZonOper($datosI);
            } 
            
           $this->session->set_flashdata('retornoExito', 'Registro Exitoso.');
    	   redirect(base_url('administrador/operador/operadoreszonas/'), 'refresh'); 
            
            
   }
   
   public function editarCiudadO($id_zon_oper){
       $id_operador = $_REQUEST['operador'];       
       $resultadoCIOP = $this->usuarios_model->actualizarCiudadO($id_zon_oper, $id_operador);
       
       if ($resultadoCIOP) {
           $this->session->set_flashdata('retornoExito', 'Registro Exitoso.');
    	   redirect(base_url('administrador/operador/operadoreszonas/'), 'refresh');
       }else{
           $this->session->set_flashdata('retornoError', 'Ocurrio un error al intentar guardar el registro.');
    	   redirect(base_url('administrador/operador/operadoreszonas/'), 'refresh');
       }
   }
   
   public function candidatos(){
        $datos["contenido"] = "administrador/operador_candidatos";        
        
        $datos["operadores"] = $this -> usuarios_model -> operadores();        
        
        $this->load->view('plantilla', $datos);	
   }
   
   public function cargaCiudad()
    {
    	if(trim($this->input->post('operador')));
        
    	{
    		$operador = $this->input->post('operador');
                
    		$ciudadesRol = $this->usuarios_model->ciudades_operador_administrador($operador);
    			
    		if(count($ciudadesRol) > 0){
    			
    			echo "	<option value=''>Seleccione...</option>";
    			
    				foreach($ciudadesRol as $fila)
    				{    			
    					echo "<option value='".$fila -> id_ciudad. "'>".$fila -> nom_mpio."</option>";
    			
    				}
    			}else{    			
    				echo "<option value=''>No existen resultados asociados...</option>";    			
    			}
    			
    		}
    }
    
    
    public function cargaRol()
    {
    	if(trim($this->input->post('ciudadOpera')));
        
    	{
    		$ciudadOpera = $this->input->post('ciudadOpera');
                
                
    		$rolesAplica = $this->usuarios_model->consulta_roles_ciudad($ciudadOpera);
    			
    		if(count($rolesAplica) > 0){
    			
    			echo "	<option value=''>Seleccione...</option>";
    			
    				foreach($rolesAplica as $fila)
    				{    			
    					echo "<option value='".$fila -> id_conv_insc. "'>".$fila -> id_convocatoria." - ".$fila -> perfil." - ".$fila -> nombre_rol_inv."</option>";
    			
    				}
    			}else{    			
    				echo "<option value=''>No existen resultados asociados...</option>";    			
    			}
    			
    		}
    }
   
       public function cargaDatosUsuario() {
	
        $id_conv_insc = trim($this->input->post('rol'));
         
         if($id_conv_insc != ''){
                
                $usuarios = $this->usuarios_model->contar_usuarios($id_conv_insc);                
                           
                $usuariosMax = $this->usuarios_model->usuariosMax($id_conv_insc);                    
                $candidatos = $this->usuarios_model->contar_candidatos($id_conv_insc);                 		
                $elegibles = $this->usuarios_model->contar_elegibles($id_conv_insc);
                $contratados = $this->usuarios_model->contar_contratados($id_conv_insc);
                $abandonaron = $this->usuarios_model->contar_abandonaron($id_conv_insc);
                
                $datos["id_conv_insc"] = $id_conv_insc;   

                $datos["candidatos"] = $candidatos[0]->candidatos;
                $datos["elegibles"] = $elegibles[0]->elegibles;
                $datos["usuariosMax"] = $usuariosMax[0]->total_personas;
                $datos["contratados"] = $contratados[0]->contratados;   
                $datos["abandonaron"] = $abandonaron[0]->abandonaron;   
                 
		$datos["usuarios"] = $this->usuarios_model->consulta_usuario_rol_ciudad_admin($id_conv_insc);
                               
                    if(count($datos["usuarios"]) > 0){
                        $this->load->view('administrador/usuariosDatosAdmin', $datos);
				//echo $data;
                    }else{
			echo "<center><h2>Sin informaci&oacute;n</h2></center>";
                    }			
			
	}else{
            echo "<center><h2>Sin informaci&oacute;n</h2></center>";
	}
             
   }
   
    public function cargaDatosElegibles() {
	
        $id_conv_insc = trim($this->input->post('rol'));
         
         if($id_conv_insc != ''){
                
                $usuarios = $this->usuarios_model->contar_usuarios($id_conv_insc);
                
                if($usuarios[0]->usuarios > 0){
                    
                   $usuariosMax = $this->usuarios_model->usuariosMax($id_conv_insc);                    
                   $usuariosMax[0]->total_personas;
                   
                   $this->generaCandidatos($id_conv_insc, $usuariosMax[0]->total_personas);
                   
                }
                
                $usuariosMax = $this->usuarios_model->usuariosMax($id_conv_insc);                    
                $candidatos = $this->usuarios_model->contar_candidatos($id_conv_insc);                 		
                $elegibles = $this->usuarios_model->contar_elegibles($id_conv_insc);
                $contratados = $this->usuarios_model->contar_contratados($id_conv_insc);
                $abandonaron = $this->usuarios_model->contar_abandonaron($id_conv_insc);
                
                $datos["id_conv_insc"] = $id_conv_insc;   

                $datos["candidatos"] = $candidatos[0]->candidatos;
                $datos["elegibles"] = $elegibles[0]->elegibles;
                $datos["usuariosMax"] = $usuariosMax[0]->total_personas;
                $datos["contratados"] = $contratados[0]->contratados;   
                $datos["abandonaron"] = $abandonaron[0]->abandonaron;   
                 
		$datos["usuarios"] = $this->usuarios_model->consulta_elegibles_rol_ciudad_admin($id_conv_insc);
                               
                    if(count($datos["usuarios"]) > 0){
                        $this->load->view('administrador/elegiblesDatosAdmin', $datos);
				//echo $data;
                    }else{
			echo "<center><h2>Sin informaci&oacute;n</h2></center>";
                    }			
			
	}else{
            echo "<center><h2>Sin informaci&oacute;n</h2></center>";
	}
             
   } 
   
  public function activarElegible ($id_conv_insc, $id_usuario){
       
          $actualiza= $this->usuarios_model->activaCandidato($id_conv_insc, $id_usuario);         
          
       if ($actualiza) {
           $this->session->set_flashdata('retornoExito', 'Registro Exitoso.');
    	   redirect(base_url('administrador/operador/candidatos/'), 'refresh');
       }else{
           $this->session->set_flashdata('retornoError', 'Ocurrio un error al intentar guardar el registro.');
    	   redirect(base_url('administrador/operador/candidatos/'), 'refresh');
       }
      
  }
   
   
    
}
