<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Contact extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('usuarios_model');
        $this->load->model('general_model');
        $this->load->model('login_model');
        $this->load->model('usuarios_model');
        $this->load->model('convocatorias_model');
        $this->load->model('perfil_model');
        $this->load->helper(array('url', 'form', 'html'));
        $this->load->library('session');
		
    	if (!($this -> session -> userdata('language'))) {
        	$this -> session -> set_userdata('language', 'spanish');
        }
        
        $user_language = $this -> session -> userdata('language');
        $this -> lang -> load('rtc_' . $user_language, $user_language);
        
        if(!$this->session->userdata('rol')){
        	$this->session->set_flashdata('retornoError', 'Su sesi&oacute;n finalizo');
        	redirect(base_url(), 'refresh');
        }    
        if($this->session->userdata('rol')!=1){
        	redirect(base_url(), 'refresh');
        }           
    }

    public function index() {

        $datos["contenido"] = "administrador/contact";
        $this->load->view('plantilla', $datos);	
    }
    
    public function guardarContact() {
    	 
    	$datosU['tipo_iden'] = $_REQUEST['tipo_iden'];
    	$datosU['celular'] = $_REQUEST['celular'];
    	$datosU['nume_iden'] = $_REQUEST['inputNumeIden'];
    	$datosU['nombres'] = utf8_encode($_REQUEST['inputNombres']);
    	$datosU['apellidos'] = utf8_encode($_REQUEST['inputApellidos']);
    	$datosU['email2'] = utf8_encode($_REQUEST['inputEmail']);
    	    
    	//Se registra la informacion del usuario, restorna el ID que asigna la BD
    	$resultadoID = $this->usuarios_model->insertarUsuario($datosU);
    	//$resultadoID = 4;
    	if ($resultadoID) {
    		$datosRol['id_usuario'] = $resultadoID;
    		$datosRol['rol'] = 8;
    		$datosRol['estado'] = 'AC';
    		$resultadoRol = $this->usuarios_model->insertarRolUsuario($datosRol);
    
    		$psswd = $_REQUEST['inputNumeIden'];
    		$datosLogin['usuario_id_usuario'] = $resultadoID;
    		$datosLogin['usuario'] = utf8_encode($_REQUEST['inputEmail']);
    		$datosLogin['clave'] = sha1(md5($psswd));
    		$datosLogin['estado'] = 'AC';
    
    		$resultadoLogin = $this->usuarios_model->insertarDatosLogin($datosLogin);
    		
    		$this->session->set_flashdata('retornoExito', 'Registro Exitoso. 
			    			El usuario de ingreso es:'. utf8_encode($_REQUEST['inputEmail']) .'. y la clave es la cedula.');
    		redirect(base_url('administrador/contact/'), 'refresh');
    				
    		}else{
    			$this->session->set_flashdata('retornoError', 'Ocurrio un error al intentar guardar el registro.');
    			redirect(base_url('administrador/contact/'), 'refresh');
    		}
    }
}
