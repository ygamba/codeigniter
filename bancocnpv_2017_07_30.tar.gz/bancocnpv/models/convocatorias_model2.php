<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * 
 */
class Convocatorias_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function investigaciones() {
        $cadena_sql = "SELECT id_investigacion, nombre_inv  ";
        $cadena_sql.= " FROM param_investigacion ";
        $cadena_sql.= " WHERE estado = 'AC' ";
		$cadena_sql.= " ORDER BY nombre_inv ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function roles() {
        $cadena_sql = "SELECT id_rol_inv, nombre_rol_inv  ";
        $cadena_sql.= " FROM param_rol_inv ";
        $cadena_sql.= " WHERE estado = 'AC' ";
		$cadena_sql.= " ORDER BY nombre_rol_inv ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function sedes() {
        $cadena_sql = "SELECT id_mpio, nom_mpio, nomb_terri  ";
        $cadena_sql.= " FROM param_territorial ter";
        $cadena_sql.= " JOIN param_subsede sed ON ter.id_territorial = sed.id_territorial ";
        $cadena_sql.= " JOIN param_mpios mpi ON sed.id_ciudad = mpi.id_mpio ";
        $cadena_sql.= " ORDER BY 3,2 ";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function insertarDatosConvocatoria($param) {
        $this->db->trans_start();
        $this->db->insert('convocatorias', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }
    
    function actualizarDatosConvocatoria($datos)
    {
        $data = array(
            'perfil' => $datos['perfil'],
            'objeto' => $datos['objeto'],
            'obligaciones' => $datos['obligaciones'],
            'honorarios' => $datos['honorarios'],
			'tipo_conv' => $datos['tipo_conv']
        );
        $this->db->where('id_convocatoria', $datos['id_convocatoria']);
        return $this->db->update('convocatorias', $data);
    }
	
	function actualizarFechaConvocatoria($datos)
    {
        $data = array(
            'fecha_inicio' => $datos['fecha_inicio'],
            'fecha_fin' => $datos['fecha_fin']
        );
        $this->db->where('id_convocatoria', $datos['id_convocatoria']);
        return $this->db->update('convocatorias_inscritos', $data);
    }
	
	
    
    public function insertarConvocatoriaInsc($param) {
        $this->db->trans_start();
        $this->db->insert('convocatorias_inscritos', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }
	
	public function insertarRequisitosEsp($param) {
        $this->db->trans_start();
        $this->db->insert('requisitos', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }
    
    public function conv_abiertas_info() {
        $cadena_sql = "SELECT con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, perfil, objeto, obligaciones, honorarios, tipo_conv, operativo  ";
        $cadena_sql.= " FROM convocatorias con ";
		$cadena_sql.= " LEFT JOIN requisitos req ON req.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " WHERE tipo_conv = 'A' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	public function conv_abiertas_clon() {
        $cadena_sql = "SELECT con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, perfil, objeto, obligaciones, honorarios, tipo_conv, operativo  ";
        $cadena_sql.= " FROM convocatorias con ";
		$cadena_sql.= " LEFT JOIN requisitos req ON req.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " WHERE tipo_conv = 'A' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function conv_cerradas_info() {
        $cadena_sql = "SELECT con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, perfil, objeto, obligaciones, honorarios, tipo_conv, operativo ";
        $cadena_sql.= " FROM convocatorias con ";
		$cadena_sql.= " JOIN requisitos req ON req.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " WHERE tipo_conv = 'C' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function info_convocatoria($id_convocatoria) {
        $cadena_sql = "SELECT distinct con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, conins.id_conv_insc, mun.nom_mpio, total_personas, total_insc, eco, fecha_inicio, fecha_fin  ";
        $cadena_sql.= " FROM convocatorias con ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " JOIN convocatorias_inscritos conins ON conins.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = conins.id_ciudad ";
        $cadena_sql.= " WHERE con.id_convocatoria = ".$id_convocatoria." ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	public function info_convocatoriaEsp($id_convocatoria) {
        $cadena_sql = "SELECT distinct con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, perfil, objeto, obligaciones, honorarios  ";
        $cadena_sql.= " FROM convocatorias con ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " WHERE con.id_convocatoria = ".$id_convocatoria." ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function info_convocatoriaEspMun($id_convocatoria) {
        $cadena_sql = "SELECT id_ciudad, total_personas, total_insc, max_inscri, fecha_inicio, fecha_fin, eco  ";
        $cadena_sql.= " FROM convocatorias_inscritos con ";
        $cadena_sql.= " WHERE con.id_convocatoria = ".$id_convocatoria." ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function info_requisitosEsp($id_convocatoria) {
        $cadena_sql = "SELECT distinct id_nivel, semestres, tiempo, area, operativo  ";
        $cadena_sql.= " FROM requisitos ";
        $cadena_sql.= " WHERE id_convocatoria = ".$id_convocatoria." ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
       
    
    public function conv_cerradas($id_convocatoria) {
        $cadena_sql = "SELECT distinct con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, total_personas, total_insc  ";
        $cadena_sql.= " FROM convocatorias con ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " JOIN convocatorias_inscritos conins ON conins.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " WHERE con.id_convocatoria = ".$id_convocatoria." ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function infoConv($id) {
        $cadena_sql = "SELECT distinct con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, id_ciudad, mun.nom_mpio, total_personas, total_insc, max_inscri  ";
        $cadena_sql.= " FROM convocatorias con ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " JOIN convocatorias_inscritos conins ON conins.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = conins.id_ciudad ";
        $cadena_sql.= " WHERE con.id_convocatoria = '".$id."' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	public function infoConvMun($id_convocatoria, $id_conv_ins) {
        $cadena_sql = "SELECT distinct con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, id_ciudad, mun.nom_mpio, total_personas, total_insc, max_inscri  ";
        $cadena_sql.= " FROM convocatorias con ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " JOIN convocatorias_inscritos conins ON conins.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = conins.id_ciudad ";
        $cadena_sql.= " WHERE conins.id_convocatoria = '".$id_convocatoria."' ";
        $cadena_sql.= " AND conins.id_conv_insc = '".$id_conv_ins."' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function listaAreas() {
        $cadena_sql = "SELECT prog.id_programa, prog.desc_programa, desc_areacono ";
        $cadena_sql.= "FROM param_programa prog ";
        $cadena_sql.= "JOIN param_areacono are ON are.id_areacono = prog.id_areacono ";
        $cadena_sql.= " WHERE are.estado = 'AC'";
        $cadena_sql.= " AND prog.estado = 'AC'";
        $cadena_sql.= " ORDER BY 3,2 ";
        
        $query = $this->db->query($cadena_sql);

        $result = $query->result();

        return $result;
    }
    
    public function listaProgramas($idNivel) {
        $cadena_sql = "SELECT prog.id_programa, prog.desc_programa, desc_areacono ";
        $cadena_sql.= "FROM param_programa prog ";
        $cadena_sql.= "JOIN param_areacono are ON are.id_areacono = prog.id_areacono ";
        $cadena_sql.= " WHERE are.estado = 'AC'";
        $cadena_sql.= " AND prog.estado = 'AC'";
        $cadena_sql.= " AND prog.id_nivel = '".$idNivel."'";
        $cadena_sql.= " ORDER BY 3,2 ";
        
        $query = $this->db->query($cadena_sql);

        $result = $query->result();

        return $result;
    }
    
    public function info_por_ciudades($id_convocatoria) {
        $cadena_sql = "SELECT distinct con.id_convocatoria, id_conv_insc , id_ciudad, mun.nom_mpio, total_personas, total_insc, max_inscri, eco  ";
        $cadena_sql.= " FROM convocatorias con ";
        $cadena_sql.= " JOIN convocatorias_inscritos conins ON conins.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = conins.id_ciudad ";
        $cadena_sql.= " WHERE con.id_convocatoria = ".$id_convocatoria." ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    
    public function verifica_usuario($tipo_iden, $nume_iden) {
        $cadena_sql = "SELECT id_usuario, tipo_iden, nume_iden, nombres, apellidos ";
        $cadena_sql.= " FROM usuario ";
        $cadena_sql.= " WHERE tipo_iden = '".$tipo_iden."' ";
        $cadena_sql.= " AND nume_iden = '".$nume_iden."' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function verificaInvitacionUsuario($id_usuario, $id_conv) {
        $cadena_sql = "SELECT id_invitacion, id_convocatoria, id_usuario ";
        $cadena_sql.= " FROM invitaciones ";
        $cadena_sql.= " WHERE id_usuario = '".$id_usuario."' ";
        $cadena_sql.= " AND id_convocatoria = '".$id_conv."' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function usuariosInvitados($id_conv) {
        $cadena_sql = "SELECT id_invitacion, id_convocatoria, inv.id_usuario, aplico, cumple_req, envio_email, fecha_aplico, fecha_correo, nombres, apellidos, tipo_iden, nume_iden, usuario, nom_mpio ";
        $cadena_sql.= " FROM invitaciones inv ";
        $cadena_sql.= " JOIN usuario usu ON usu.id_usuario = inv.id_usuario ";
        $cadena_sql.= " JOIN login log ON log.usuario_id_usuario = inv.id_usuario ";
		$cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = inv.id_ciudad ";
        $cadena_sql.= " WHERE id_convocatoria = '".$id_conv."' ";
        $cadena_sql.= " AND inv.estado = 'AC' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	public function requisitosInscritos($id_conv) {
        $cadena_sql = "SELECT id_ciudad, mun.nom_mpio, total_personas, max_inscri, fecha_inicio, fecha_fin ";
        $cadena_sql.= " FROM convocatorias_inscritos cinv ";
        $cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = cinv.id_ciudad ";
        $cadena_sql.= " WHERE id_convocatoria = '".$id_conv."' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function requisitosInscritos2($id_conv) {
        $cadena_sql = "SELECT id_nivel, semestres, tiempo, area, operativo ";
        $cadena_sql.= " FROM requisitos req ";
        $cadena_sql.= " WHERE id_convocatoria = '".$id_conv."' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	public function requisitosInscritosMun($id_conv, $id_conv_insc) {
        $cadena_sql = "SELECT id_ciudad, mun.nom_mpio, total_personas, max_inscri, fecha_inicio, fecha_fin ";
        $cadena_sql.= " FROM convocatorias_inscritos cinv ";
        $cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = cinv.id_ciudad ";
        $cadena_sql.= " WHERE id_convocatoria = '".$id_conv."' ";
        $cadena_sql.= " AND cinv.id_conv_insc = '".$id_conv_insc."' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function requisitosInscritos2Mun($id_conv) {
        $cadena_sql = "SELECT id_nivel, semestres, tiempo, area, operativo ";
        $cadena_sql.= " FROM requisitos req ";
        $cadena_sql.= " WHERE id_convocatoria = '".$id_conv."' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function documentosCompletos($id_usuario, $id_conv) {
        $cadena_sql = "SELECT doc_estado, observaciones ";
        $cadena_sql.= " FROM usuario_convocatoria  ";
        $cadena_sql.= " WHERE id_convocatoria = '".$id_conv."' ";
        $cadena_sql.= " AND id_usuario = '".$id_usuario."' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function insertarUsuarioInvitacion($param) {
        $this->db->trans_start();
        $this->db->insert('invitaciones', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }
    
    
    public function guardarRequisitos($param) {
        $this->db->trans_start();
        $this->db->insert('requisitos', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }
    
    public function verificaRequisitos($id_conv) {
        $cadena_sql = "SELECT id_requisito, id_convocatoria, id_nivel, semestres, tiempo, area, operativo  ";
        $cadena_sql.= "FROM requisitos ";
        $cadena_sql.= "WHERE id_convocatoria = '" . $id_conv . "'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }   
	
	public function infoRequisitos($id_conv) {
        $cadena_sql = "SELECT id_requisito, id_convocatoria, rq.id_nivel, nf.descripcion, semestres, tiempo, area, operativo  ";
        $cadena_sql.= "FROM requisitos rq ";
		$cadena_sql.= "JOIN param_nivel_formacion nf ON rq.id_nivel = nf.id_nivel ";
        $cadena_sql.= "WHERE id_convocatoria = '" . $id_conv . "'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }   
    
    function actualizarRequisitos($parametros)
    {
        $data = array(
            'id_nivel' => $parametros['id_nivel'],
            'semestres' => $parametros['semestres'],
            'tiempo' => $parametros['tiempo'],
            'area' => $parametros['area'],
            'operativo' => $parametros['operativo']
        );
        
        $array = array('id_requisito' => $parametros['id_requisito']);
        $this->db->where($array);
        return $this->db->update('requisitos', $data);
        
    }
    
    public function datosUsuario($id_usuario) {
        $cadena_sql = "SELECT us.id_usuario, nombres, apellidos, usuario, rol FROM login lo ";
        $cadena_sql.= "JOIN usuario us ON usuario_id_usuario = us.id_usuario ";
        $cadena_sql.= "JOIN usuario_rol ur ON ur.id_usuario = us.id_usuario ";
        $cadena_sql.= "WHERE us.id_usuario = '" . $id_usuario . "'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    function actualizarEnvio($id_usuario, $id_conv)
    {
        $data = array(
            'fecha_correo' => date('Y-m-d H:i:s'),
            'envio_email' => 'SI'
        );
        
        $array = array('id_usuario' => $id_usuario, 'id_convocatoria' => $id_conv);
        $this->db->where($array);
        return $this->db->update('invitaciones', $data);
        
    }
    
    public function buscarInscritos($id_conv) {
        $cadena_sql = "SELECT id_conv_insc, id_convocatoria, id_ciudad, total_personas, total_insc, max_inscri, fecha_inicio, fecha_fin ";
        $cadena_sql.= "FROM convocatorias_inscritos ";
        $cadena_sql.= "WHERE id_convocatoria = '" . $id_conv . "'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function informacionPerfil($investigacion, $rol) {
        $cadena_sql = "SELECT perfil, objeto ";
        $cadena_sql.= "FROM param_perfil_inves ";
        $cadena_sql.= " WHERE id_investigacion = '" . $investigacion . "'";
        $cadena_sql.= " AND id_rol_inv = '" . $rol . "'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    function actualizarInscritos($parametros)
    {
        $data = array(
            'total_personas' => $parametros['total_personas'],
            'max_inscri' => $parametros['max_inscri'],
            'eco' => $parametros['eco']
        );
        
        $array = array('id_conv_insc' => $parametros['id_conv_insc']);
        $this->db->where($array);
        return $this->db->update('convocatorias_inscritos', $data);
        
    }
    
    //CIUDADANO
    
    
    public function ciudadano_conv_participa($id_usuario) {
        $cadena_sql = "SELECT usco.id_usu_conv, usco.id_usuario, usco.id_convocatoria, usco.estado, inve.nombre_inv, nombre_rol_inv, perfil, objeto, obligaciones, honorarios, cins.id_conv_insc, cins.id_ciudad, mpio.nom_mpio, fecha_inicio, fecha_fin, total_personas, max_inscri ";
        $cadena_sql.= "FROM usuario_convocatoria usco ";
        $cadena_sql.= "JOIN convocatorias conv ON usco.id_convocatoria = conv.id_convocatoria ";
        $cadena_sql.= "JOIN convocatorias_inscritos cins ON cins.id_convocatoria = conv.id_convocatoria AND usco.id_conv_insc = cins.id_conv_insc ";
        $cadena_sql.= "JOIN param_investigacion inve ON inve.id_investigacion = conv.id_investigacion ";
        $cadena_sql.= "JOIN param_rol_inv rol ON rol.id_rol_inv = conv.id_rol ";
		$cadena_sql.= "JOIN param_mpios mpio ON mpio.id_mpio = cins.id_ciudad ";
        $cadena_sql.= "WHERE usco.id_usuario = '" . $id_usuario . "'";
		$cadena_sql.= " AND usco.estado = 'AC'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    
    
    public function ciudadano_conv_abiertas() {
        $cadena_sql = "SELECT conv.id_convocatoria, inve.nombre_inv, nombre_rol_inv, req.id_nivel, req.semestres, req.tiempo, perfil, objeto, obligaciones, honorarios, cins.id_conv_insc, cins.id_ciudad, mpio.nom_mpio, fecha_inicio, fecha_fin, total_personas, max_inscri ";
        $cadena_sql.= "FROM convocatorias conv ";
		$cadena_sql.= "JOIN requisitos req ON req.id_convocatoria = conv.id_convocatoria ";
		$cadena_sql.= "JOIN convocatorias_inscritos cins ON cins.id_convocatoria = conv.id_convocatoria ";
        $cadena_sql.= "JOIN param_investigacion inve ON inve.id_investigacion = conv.id_investigacion ";
        $cadena_sql.= "JOIN param_rol_inv rol ON rol.id_rol_inv = conv.id_rol ";
		$cadena_sql.= "JOIN param_mpios mpio ON mpio.id_mpio = cins.id_ciudad ";
        $cadena_sql.= "WHERE conv.tipo_conv = 'A'";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function ciudadano_conv_cerradas($id_usuario) {
        $cadena_sql = "SELECT conv.id_convocatoria, inve.nombre_inv, nombre_rol_inv, req.id_nivel, req.semestres, req.tiempo, perfil, objeto, obligaciones, honorarios, cins.id_conv_insc, cins.id_ciudad, mpio.nom_mpio, fecha_inicio, fecha_fin, total_personas, max_inscri ";
        $cadena_sql.= "FROM invitaciones inv ";
        $cadena_sql.= "JOIN convocatorias conv ON inv.id_convocatoria = conv.id_convocatoria ";
		$cadena_sql.= "JOIN requisitos req ON req.id_convocatoria = conv.id_convocatoria ";
		$cadena_sql.= "JOIN convocatorias_inscritos cins ON cins.id_convocatoria = conv.id_convocatoria AND inv.id_ciudad = cins.id_ciudad  ";
        $cadena_sql.= "JOIN param_investigacion inve ON inve.id_investigacion = conv.id_investigacion ";
        $cadena_sql.= "JOIN param_rol_inv rol ON rol.id_rol_inv = conv.id_rol ";
        $cadena_sql.= "JOIN param_mpios mpio ON mpio.id_mpio = cins.id_ciudad ";
        $cadena_sql.= " WHERE conv.tipo_conv = 'C'";
        $cadena_sql.= " AND inv.id_usuario = '".$id_usuario."'";
		        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	public function verificaCruceConvocatoria($id_usuario) {
        $cadena_sql = "SELECT id_usu_conv, id_usuario, id_convocatoria, estado ";
        $cadena_sql.= "FROM usuario_convocatoria ";
        $cadena_sql.= " WHERE id_usuario = '".$id_usuario."'";
        $cadena_sql.= " AND estado = 'AC'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    public function verificaDisponibilidad($idConvocatoria, $id_conv_ins) {
        $cadena_sql = "SELECT id_ciudad, total_personas, total_insc, max_inscri, fecha_inicio, fecha_fin ";
        $cadena_sql.= "FROM convocatorias_inscritos ";
        $cadena_sql.= " WHERE id_conv_insc = '".$id_conv_ins."'";
        $cadena_sql.= " AND id_convocatoria = '".$idConvocatoria."'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }  
    
    
    public function totalPersonasInscritas($idConvocatoria) {
        $cadena_sql = "SELECT count(id_convocatoria) total ";
        $cadena_sql.= "FROM usuario_convocatoria ";
        $cadena_sql.= " WHERE id_convocatoria = '".$idConvocatoria."'";
        $cadena_sql.= " AND estado = 'AC'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
		
    public function totalInscritos($idConvocatoria, $id_conv_ins) {
        $cadena_sql = "SELECT count(id_convocatoria) total ";
        $cadena_sql.= "FROM usuario_convocatoria ";
        $cadena_sql.= " WHERE id_convocatoria = '".$idConvocatoria."'";
        $cadena_sql.= " AND id_conv_insc = '".$id_conv_ins."'";
        $cadena_sql.= " AND estado = 'AC'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	public function borrarCiudadConvocatoria($id_convocatoria, $id_conv_insc){
		$this->db->where('id_convocatoria',$id_convocatoria);
        $this->db->where('id_conv_insc',$id_conv_insc);
        return $this->db->delete('convocatorias_inscritos');
	}
	
	public function personasInscritas($idConvocatoria, $id_conv_insc) {
        $cadena_sql = "SELECT uc.id_usuario, us.nombres, us.apellidos, tipo_iden, nume_iden, telefono, celular, lo.usuario  ";
        $cadena_sql.= "FROM usuario_convocatoria uc ";
		$cadena_sql.= "JOIN usuario us ON us.id_usuario = uc.id_usuario ";
		$cadena_sql.= "JOIN login lo ON lo.usuario_id_usuario = us.id_usuario  ";
        $cadena_sql.= " WHERE id_convocatoria = '".$idConvocatoria."'";
		$cadena_sql.= " AND id_conv_insc = '".$id_conv_insc."'";
        $cadena_sql.= " AND uc.estado = 'AC'";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	public function personasDatos($identificacion) {
        $cadena_sql = "SELECT us.id_usuario, us.nombres, us.apellidos, us.tipo_iden, us.nume_iden, id_avatar, id_docIden ";
		$cadena_sql .= " FROM usuario us  ";		
		$cadena_sql .= " WHERE nume_iden = ".$identificacion;
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	
    
    
    public function insertarConvocatoriaUsuario($param) {
        $this->db->trans_start();
        $this->db->insert('usuario_convocatoria', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }

	public function personasInscritos() {
        $cadena_sql = "SELECT uc.id_usuario, uc.id_convocatoria, uc.id_conv_insc, us.nombres, us.apellidos, us.tipo_iden, us.nume_iden, nom_mpio, inv.nombre_inv, rol.nombre_rol_inv, req.operativo ";
		$cadena_sql .= " FROM usuario_convocatoria uc  ";
		$cadena_sql .= " JOIN usuario us ON us.id_usuario = uc.id_usuario  ";
		$cadena_sql .= " JOIN convocatorias con ON con.id_convocatoria = uc.id_convocatoria  ";
		$cadena_sql .= " LEFT JOIN requisitos req ON req.id_convocatoria = con.id_convocatoria ";
		$cadena_sql .= " JOIN convocatorias_inscritos cins ON cins.id_convocatoria = uc.id_convocatoria  ";
		$cadena_sql .= " AND cins.id_conv_insc = uc.id_conv_insc  ";
		$cadena_sql .= " JOIN param_mpios mpio ON mpio.id_mpio = cins.id_ciudad  ";
		$cadena_sql .= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion  ";
		$cadena_sql .= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol WHERE uc.estado!='IN' ";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }

	public function borrarCiudadUsuario($id_usuario, $id_convocatoria, $id_conv_insc){
		$this->db->where('id_usuario',$id_usuario);
        $this->db->where('id_convocatoria',$id_convocatoria);
		$this->db->where('id_conv_insc',$id_conv_insc);
        return $this->db->delete('usuario_convocatoria');
	}
	
	
    public function info_invitacion($id_convocatoria, $id_usuario) {
        $cadena_sql = "SELECT id_ciudad, aplico, fecha_aplico  ";
        $cadena_sql.= " FROM invitaciones ";
        $cadena_sql.= " WHERE id_convocatoria = ".$id_convocatoria." ";
		$cadena_sql.= " AND id_usuario = ".$id_usuario." ";
		

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	function actualizarInvitacionAplica($parametros)
    {
        $data = array(
            'fecha_aplico' => $parametros['fecha_aplico'],
            'aplico' => $parametros['aplico']
        );
        
        $array = array('id_convocatoria' => $parametros['id_convocatoria'], 'id_usuario' => $parametros['id_usuario']);
        $this->db->where($array);
        return $this->db->update('invitaciones', $data);
        
    }
	
	//COORDINADOR
	
	public function convocatorias_coor_abiertas($ciudad) {
        $cadena_sql = "SELECT distinct con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, conins.id_conv_insc, mun.nom_mpio, total_personas, total_insc, eco, fecha_inicio, fecha_fin, operativo  ";
        $cadena_sql.= " FROM convocatorias con ";
        $cadena_sql.= " LEFT JOIN requisitos req ON req.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " JOIN convocatorias_inscritos conins ON conins.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = conins.id_ciudad ";
        $cadena_sql.= " WHERE conins.id_ciudad = ".$ciudad." ";
		$cadena_sql.= " AND con.tipo_conv = 'A' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	public function convocatorias_coor_cerradas($ciudad) {
        $cadena_sql = "SELECT distinct con.id_convocatoria, con.id_investigacion, nombre_inv, con.id_rol, nombre_rol_inv, conins.id_conv_insc, mun.nom_mpio, total_personas, total_insc, eco, fecha_inicio, fecha_fin, operativo  ";
        $cadena_sql.= " FROM convocatorias con ";
        $cadena_sql.= " LEFT JOIN requisitos req ON req.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_investigacion inv ON inv.id_investigacion = con.id_investigacion ";
        $cadena_sql.= " JOIN param_rol_inv rol ON rol.id_rol_inv = con.id_rol ";
        $cadena_sql.= " JOIN convocatorias_inscritos conins ON conins.id_convocatoria = con.id_convocatoria ";
        $cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = conins.id_ciudad ";
        $cadena_sql.= " WHERE conins.id_ciudad = ".$ciudad." ";
		$cadena_sql.= " AND con.tipo_conv = 'C' ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	function actualizarDocumentos($id_convocatoria, $id_conv_insc, $id_usuario, $documentos, $observaciones)
    {
        $data = array(
            'doc_estado' => $documentos,
            'observaciones' => $observaciones
        );
        
        $array = array('id_usuario' => $id_usuario, 'id_convocatoria' => $id_convocatoria, 'id_conv_insc' => $id_conv_insc);
        $this->db->where($array);
        return $this->db->update('usuario_convocatoria', $data);
        
    }
	
	public function buscarCiudad($ciudad) {
        $cadena_sql = "SELECT id_mpio, nom_mpio  ";
        $cadena_sql.= " FROM param_mpios ";
        $cadena_sql.= " WHERE nom_mpio = '".$ciudad."'  ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
        
	public function ciudades_coordinador($username) {
        $cadena_sql = "SELECT nombres, apellidos, email, estado, id_ciudad, mun.nom_mpio ";
        $cadena_sql.= "FROM coordinadores coor ";
		$cadena_sql.= " JOIN param_mpios mun ON mun.id_mpio = coor.id_ciudad ";
        $cadena_sql.= "WHERE email = '" . $username . "' ";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    
    public function buscarCiudadConvocatoria($id_convocatoria, $ciudad) {
        $cadena_sql = "SELECT *  ";
        $cadena_sql.= " FROM convocatorias_inscritos ";
        $cadena_sql.= " WHERE id_convocatoria = ".$id_convocatoria." ";
		$cadena_sql.= " AND id_ciudad =  ".$ciudad." ";

        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
	
	function liberarUsuario($id_usuario)
    {
        $data = array(
            'estado' => 'IN'
        );
        $this->db->where('id_usuario', $id_usuario);
        return $this->db->update('usuario_convocatoria', $data);
    }
    
	
}
