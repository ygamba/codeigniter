<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * 
 */
class usuarios_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
	
	function consulta_usuario($documento, $nombres, $apellidos, $correo) {
        $this->load->database();
 
        $cadena_sql = "SELECT DISTINCT us.id_usuario, nombres, apellidos, tipo_iden, nume_iden, fecha_naci, sexo, celular, telefono, usuario, id_avatar, id_docIden ";
        $cadena_sql.= "FROM usuario us ";
        $cadena_sql.= "JOIN login lo ON us.id_usuario = lo.usuario_id_usuario  ";
        $cadena_sql.= "WHERE 1=1 ";
		
		if($documento != ''){
			$cadena_sql.= "AND nume_iden = '".$documento."' ";
		}
		if($nombres != ''){
			$cadena_sql.= "AND nombres like '%".$nombres."%' ";
		}
		if($apellidos != ''){
			$cadena_sql.= "AND apellidos like '%".$apellidos."%' ";
		}
		if($correo != ''){
			$cadena_sql.= "AND lo.usuario like '%".$correo."%' ";
		}
		
		

        $query = $this->db->query($cadena_sql);

        return $query->result();
    }
    
    function consulta_invitaciones($id_usuario) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT DISTINCT inv.id_convocatoria, tipo_conv, nombre_inv, nombre_rol_inv, nom_mpio, aplico, fecha_aplico, envio_email, fecha_correo, req.operativo ";
    	$cadena_sql.= "FROM invitaciones inv ";
    	$cadena_sql.= "JOIN convocatorias con ON con.id_convocatoria = inv.id_convocatoria  ";
    	$cadena_sql.= "JOIN param_investigacion pinv ON pinv.id_investigacion = con.id_investigacion ";
    	$cadena_sql.= "JOIN param_rol_inv prol ON prol.id_rol_inv = con.id_rol ";
    	$cadena_sql.= "JOIN param_mpios mpio ON mpio.id_mpio = inv.id_ciudad ";
    	$cadena_sql.= "JOIN requisitos req ON con.id_convocatoria = req.id_convocatoria ";
    	$cadena_sql.= "WHERE inv.estado = 'AC' ";
    	$cadena_sql.= "AND inv.id_usuario = ".$id_usuario." ";
    
    	$query = $this->db->query($cadena_sql);
    
    	return $query->result();
    }
    
    function consulta_aplicacion($id_usuario) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT DISTINCT usc.id_convocatoria, tipo_conv, nombre_inv, nombre_rol_inv, nom_mpio, doc_estado, observaciones, usc.estado, req.operativo ";
    	$cadena_sql.= "FROM usuario_convocatoria usc ";
    	$cadena_sql.= "JOIN convocatorias con ON con.id_convocatoria = usc.id_convocatoria ";
    	$cadena_sql.= "JOIN convocatorias_inscritos conins ON conins.id_conv_insc = usc.id_conv_insc ";
    	$cadena_sql.= "JOIN param_investigacion pinv ON pinv.id_investigacion = con.id_investigacion ";
    	$cadena_sql.= "JOIN param_rol_inv prol ON prol.id_rol_inv = con.id_rol ";
    	$cadena_sql.= "JOIN param_mpios mpio ON mpio.id_mpio = conins.id_ciudad ";
    	$cadena_sql.= "JOIN requisitos req ON con.id_convocatoria = req.id_convocatoria ";
    	$cadena_sql.= "WHERE usc.id_usuario = ".$id_usuario." ";
    	$cadena_sql.= "AND usc.estado = 'AC' ";
    
    	$query = $this->db->query($cadena_sql);
    
    	return $query->result();
    }

    public function roles() {
        $query = $this->db->query("SELECT * FROM roles WHERE estado = '1'");
        $result = $query->result();
        return $result;
    }

    function obtener_datosRol1() {
        $this->load->database();

        $cadena_sql = "SELECT us.id_usuario, nombres, apellidos, email, pa.desc_pais ";
        $cadena_sql.= "FROM usuario us ";
        $cadena_sql.= "JOIN usuario_rol ur ON ur.id_usuario = us.id_usuario ";
        $cadena_sql.= "JOIN param_paises pa ON pa.codi_pais = us.codi_pais  ";
        $cadena_sql.= "WHERE rol='1' ";
        $query = $this->db->query($cadena_sql);

        return $query->result();
    }

    function obtener_datosRol2() {
        $this->load->database();

        $cadena_sql = "SELECT us.id_usuario, nombres, apellidos, email, pa.desc_pais ";
        $cadena_sql.= "FROM usuario us ";
        $cadena_sql.= "JOIN usuario_rol ur ON ur.id_usuario = us.id_usuario ";
        $cadena_sql.= "JOIN param_paises pa ON pa.codi_pais = us.codi_pais  ";
        $cadena_sql.= "WHERE rol='2' ";
        $query = $this->db->query($cadena_sql);

        return $query->result();
    }

    function obtener_datosRol3() {
        $this->load->database();

        $cadena_sql = "SELECT us.id_usuario, nombres, apellidos, email, pa.desc_pais ";
        $cadena_sql.= "FROM usuario us ";
        $cadena_sql.= "JOIN usuario_rol ur ON ur.id_usuario = us.id_usuario ";
        $cadena_sql.= "JOIN param_paises pa ON pa.codi_pais = us.codi_pais  ";
        $cadena_sql.= "WHERE rol='3' ";

        $query = $this->db->query($cadena_sql);

        return $query->result();
    }

    function tipos_identificacion() {
        $this->load->database();

        $cadena_sql = "SELECT referencia, descripcion  ";
        $cadena_sql.= "FROM param_tipo_iden ";
        $cadena_sql.= "WHERE estado='AC' ";

        $query = $this->db->query($cadena_sql);

        return $query->result();
    }

    function paises() {
        $this->load->database();

        $cadena_sql = "SELECT codi_pais, desc_pais ";
        $cadena_sql.= "FROM param_paises ";

        $query = $this->db->query($cadena_sql);

        return $query->result();
    }

    public function obtenerCargo($inputCargo) {

        $this->load->database();

        $cadena_sql = "SELECT id_cargo, desc_cargo ";
        $cadena_sql.= "FROM param_cargo ";
        $cadena_sql.= "WHERE desc_cargo like '%" . $inputCargo . "%' ";

        $query = $this->db->query($cadena_sql);

        $registro = $query->result();

        return $registro;
    }

    public function obtenerEspeci($inputEspec) {

        $this->load->database();

        $cadena_sql = "SELECT id_espec, desc_espec ";
        $cadena_sql.= "FROM param_especialidad	 ";
        $cadena_sql.= "WHERE desc_espec like '%" . $inputEspec . "%' ";

        $query = $this->db->query($cadena_sql);

        $registro = $query->result();

        return $registro;
    }

    public function validarUsuarioCorreo($inputEmail) {

        $this->load->database();

        $cadena_sql = "SELECT usuario_id_usuario, usuario ";
        $cadena_sql.= "FROM login ";
        $cadena_sql.= "WHERE usuario = '" . $inputEmail . "' ";

        $query = $this->db->query($cadena_sql);

        if ($query->num_rows() > 0) {
            $registro = $query->result();
        } else {
            $registro = '';
        }
        return $registro;
    }

    public function validarUsuarioIdentificacion($tipo_iden, $inputNumero) {

        $this->load->database();

        $cadena_sql = "SELECT us.tipo_iden, us.nume_iden ";
        $cadena_sql.= "FROM usuario us ";
        $cadena_sql.= "WHERE us.tipo_iden = '" . $tipo_iden . "' ";
        $cadena_sql.= "AND us.nume_iden = " . $inputNumero . " ";

        $query = $this->db->query($cadena_sql);

        if ($query->num_rows() > 0) {
            $registro = $query->result();
        } else {
            $registro = '';
        }

        return $registro;
    }

    public function insertarUsuario($param) {
        $this->db->trans_start();
        $this->db->insert('usuario', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }

    public function insertarRolUsuario($param) {
        $this->db->trans_start();
        $this->db->insert('usuario_rol', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }

    public function insertarDatosUsuario($param) {
        $this->db->trans_start();
        $this->db->insert('usuario_datos', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }
    
    public function insertarDatosLogin($param) {
        $this->db->trans_start();
        $this->db->insert('login', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }

    function datosUsuario($idUsuario) {
        $this->load->database();
 
        $cadena_sql = "SELECT us.id_usuario, nombres, apellidos, email, codi_pais, cargo, especialidad, rol ";
        $cadena_sql.= "FROM usuario us ";
        $cadena_sql.= "JOIN usuario_datos ud ON us.id_usuario = ud.id_usuario  ";
        $cadena_sql.= "JOIN usuario_rol ur ON us.id_usuario = ur.id_usuario ";
        $cadena_sql.= "WHERE us.id_usuario = ".$idUsuario;

        $query = $this->db->query($cadena_sql);

        return $query->result();
    }
    
    function actualizarUsuario($id_usuario, $nombres, $apellidos, $email, $codi_pais)
    {
        $data = array(
            'nombres' => $nombres,
            'apellidos' => $apellidos,
            'email' => $email,
            'codi_pais' => $codi_pais
        );
        $this->db->where('id_usuario', $id_usuario);
        return $this->db->update('usuario', $data);
    }
	
    function activarCuenta($id_usuario)
    {
        $data = array(
            'estado' => 'AC'
        );
        $this->db->where('usuario_id_usuario', $id_usuario);
        return $this->db->update('login', $data);
    }
	
    function activarFecha($id_usuario)
    {
        $data = array(
            'fecha_acti' => date('Y-m-d H:i:s')
        );
        $this->db->where('id_usuario', $id_usuario);
        return $this->db->update('usuario', $data);
    }
    
    function actualizarUsuarioDatos($id_usuario, $cargo, $especialidad)
    {
        $data = array(
            'cargo' => $cargo,
            'especialidad' => $especialidad
        );
        $this->db->where('id_usuario', $id_usuario);
        return $this->db->update('usuario_datos', $data);
    }
    
    function actualizarUsuarioRol($id_usuario, $rol)
    {
        $data = array(
            'rol' => $rol
        );
        $this->db->where('id_usuario', $id_usuario);
        return $this->db->update('usuario_rol', $data);
    }
    
    function eliminar_usuario($id_usuario)
    {
        $data = array(
            'rol' => $rol
        );
        $this->db->where('id_usuario', $id_usuario);
        return $this->db->update('usuario_rol', $data);
    }
    
    function consultaridentificacion($cedula) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT us.nume_iden ";
    	$cadena_sql.= "FROM usuario us ";
    	$cadena_sql.= "WHERE us.nume_iden = ".$cedula;
    
    	$query = $this->db->query($cadena_sql);
    
    	return $query->result();
    }
    
    function consultarid($idusuario, $cedula) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT us.id_usuario ";
    	$cadena_sql.= "FROM usuario us ";
    	$cadena_sql.= "WHERE us.nume_iden = ".$cedula. " AND id_usuario!=".$idusuario;
    
    	$query = $this->db->query($cadena_sql);
    
    	return $query->result();
    }
    
    function consultarIdUsuario($cedula) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT us.id_usuario ";
    	$cadena_sql.= "FROM usuario us ";
    	$cadena_sql.= "WHERE us.nume_iden = ".$cedula;
    
    	$query = $this->db->query($cadena_sql);
    	
    	return $query->result();
    }
    
    function operadores() {
    	$this->load->database();
    
    	$cadena_sql = "SELECT op.id_operador, op.nombre ";
    	$cadena_sql.= "FROM operadores op ";    	
    
    	$query = $this->db->query($cadena_sql);
    	
    	return $query->result();
    }
    
     public function insertarOperador($param) {
        $this->db->trans_start();
        $this->db->insert('operadores', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }
    
        function actualizarOperador($id_operador, $nombre)
    {
        $data = array(
            'nombre' => $nombre
        );
        $this->db->where('id_operador', $id_operador);
        return $this->db->update('operadores', $data);
    }
    
     public function operadorC(){
               
        $this->db->select('usuario.id_usuario,usuario.nombres,usuario.apellidos,operadores.id_operador,operadores.nombre ');
        $this->db->from('usuario');
        $this->db->join('usuario_rol', 'usuario_rol.id_usuario = usuario.id_usuario', 'left');
        $this->db->join('operadores', 'operadores.id_operador = usuario.id_operador', 'left');        
        $this->db->where('usuario_rol.rol = 9');
        $query=$this->db->get();
	return $query->result(); 
         
     }
     
     public function actualizarUsuarioOp($id_usuario, $id_operador){
               
        $data = array(
            'id_operador' => $id_operador
        );
        $this->db->where('id_usuario', $id_usuario);
        return $this->db->update('usuario', $data);
         
     }
     
        public function insertarZonOper($param) {
        $this->db->trans_start();
        $this->db->insert('zonas_operador', $param);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return  $insert_id;
    }
    
    public function zonasOperador() {
    	$this->load->database();
    
        
        $this->db->select('zonas_operador.id_zon_oper, zonas_operador.id_ciudad,zonas_operador.id_operador, operadores.nombre, param_mpios.nom_mpio  ');
        $this->db->distinct('zonas_operador.id_ciudad');
        $this->db->from('zonas_operador');
        $this->db->join('operadores', 'operadores.id_operador = zonas_operador.id_operador', 'left');
        $this->db->join('param_mpios', 'param_mpios.id_mpio = zonas_operador.id_ciudad', 'left');                
        $query=$this->db->get();
	return $query->result(); 
      
    }
    
     public function actualizarCiudadO($id_zon_oper, $id_operador){
               
        $data = array(
            'id_operador' => $id_operador
        );
        $this->db->where('id_zon_oper', $id_zon_oper);
        return $this->db->update('zonas_operador', $data);
         
     }
     
     
     public function ciudades_operador($id_usuario) {
        $cadena_sql = "SELECT distinct id_ciudad, mun.nom_mpio ";
        $cadena_sql.= "FROM zonas_operador zop ";
        $cadena_sql.= "JOIN param_mpios mun ON mun.id_mpio = zop.id_ciudad ";
	$cadena_sql.= "JOIN usuario us ON us.id_operador = zop.id_operador ";
        $cadena_sql.= "WHERE id_usuario = '" . $id_usuario . "' ";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
     
     public function ciudades_operador_administrador($id_operador) {
        $cadena_sql = "SELECT distinct id_ciudad, mun.nom_mpio ";
        $cadena_sql.= "FROM zonas_operador zop ";
        $cadena_sql.= "JOIN param_mpios mun ON mun.id_mpio = zop.id_ciudad ";
	$cadena_sql.= "JOIN usuario us ON us.id_operador = zop.id_operador ";
        $cadena_sql.= "WHERE zop.id_operador = '" . $id_operador . "' ";
        
        $query = $this->db->query($cadena_sql);
        
        $result = $query->result();
        
        return $result;
    }
    
    
    
    function consulta_roles_ciudad($ciudad) {

        $this->db->select('convocatorias_inscritos.id_conv_insc, convocatorias.id_convocatoria, convocatorias.perfil, param_rol_inv.nombre_rol_inv ');
        $this->db->from('convocatorias_inscritos');
        $this->db->join('convocatorias', 'convocatorias_inscritos.id_convocatoria = convocatorias.id_convocatoria', 'left');        
        $this->db->join('param_rol_inv', 'convocatorias.id_rol = param_rol_inv.id_rol_inv', 'left');        
        $this->db->where('convocatorias_inscritos.id_ciudad = '.$ciudad);               
        $query=$this->db->get();
	return $query->result(); 
        
    }
        
   function contar_usuarios($id_conv_insc) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT count(*)  as usuarios ";
    	$cadena_sql.= "FROM usuario_convocatoria uc ";
    	$cadena_sql.= "WHERE uc.id_conv_insc = ".$id_conv_insc;
        $cadena_sql.= " AND uc.doc_estado = 1";
        $cadena_sql.= " AND uc.contrato = 0";
    
    	$query = $this->db->query($cadena_sql);
    	
    	return $query->result();
    }
    
    function contar_candidatos($id_conv_insc) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT count(*)  as candidatos ";
    	$cadena_sql.= "FROM usuario_convocatoria uc ";
    	$cadena_sql.= "WHERE uc.id_conv_insc = ".$id_conv_insc;
        $cadena_sql.= " AND uc.doc_estado = 1";
        $cadena_sql.= " AND uc.contrato = 1";
    
    	$query = $this->db->query($cadena_sql);
    	
    	return $query->result();
    }
    
    function contar_elegibles($id_conv_insc) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT count(*)  as elegibles ";
    	$cadena_sql.= "FROM usuario_convocatoria uc ";
    	$cadena_sql.= "WHERE uc.id_conv_insc = ".$id_conv_insc;
        $cadena_sql.= " AND uc.doc_estado = 1";
        $cadena_sql.= " AND uc.contrato = 2";
    
    	$query = $this->db->query($cadena_sql);
    	
    	return $query->result();
    }
    
    function contar_contratados($id_conv_insc) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT count(*)  as contratados ";
    	$cadena_sql.= "FROM usuario_convocatoria uc ";
    	$cadena_sql.= "WHERE uc.id_conv_insc = ".$id_conv_insc;
        $cadena_sql.= " AND uc.doc_estado = 1";
        $cadena_sql.= " AND uc.contrato = 3";
    
    	$query = $this->db->query($cadena_sql);
    	
    	return $query->result();
    }
    
    function contar_abandonaron($id_conv_insc) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT count(*)  as abandonaron ";
    	$cadena_sql.= "FROM usuario_convocatoria uc ";
    	$cadena_sql.= "WHERE uc.id_conv_insc = ".$id_conv_insc;
        $cadena_sql.= " AND uc.doc_estado = 1";
        $cadena_sql.= " AND uc.contrato = 4";
    
    	$query = $this->db->query($cadena_sql);
    	
    	return $query->result();
    }
    
    
    
    function usuariosMax($id_conv_insc) {
    	$this->load->database();
    
    	$cadena_sql = "SELECT total_personas ";
    	$cadena_sql.= "FROM convocatorias_inscritos as ci ";
    	$cadena_sql.= "WHERE ci.id_conv_insc = ".$id_conv_insc;
        
    	$query = $this->db->query($cadena_sql);
    	
    	return $query->result();
    }
    
   
    function usuarios($id_conv_insc) {
        $this->db->select('usuario_convocatoria.id_usu_conv ');
        $this->db->from('usuario_convocatoria');        
        $this->db->join('smca_usuarios_seguimiento', 'usuario_convocatoria.id_usuario = smca_usuarios_seguimiento.id_usuario', 'left');        
        $this->db->where('usuario_convocatoria.doc_estado = 1 ');
        $this->db->where('usuario_convocatoria.contrato = 0 ');
        $this->db->where('usuario_convocatoria.id_conv_insc = '.$id_conv_insc);                       
        $this->db->order_by('nota', 'DESC');
        $query=$this->db->get();
	return $query->result(); 
    }
    
    
      public function usuariosUpdate($id_usu_conv, $contrato){
               
        $data = array(
            'contrato' => $contrato
        );
        $this->db->where('id_usu_conv', $id_usu_conv);
        return $this->db->update('usuario_convocatoria', $data);
         
     }
    
    function consulta_usuario_rol_ciudad($id_conv_insc) {
        $this->db->select('usuario.id_usuario, usuario.nombres, usuario.apellidos, usuario.tipo_iden, usuario.nume_iden, usuario.fecha_naci, usuario.sexo, usuario.celular, usuario.telefono, usuario.id_avatar, usuario.id_docIden, smca_usuarios_seguimiento.nota ');
        $this->db->from('usuario');
        $this->db->join('usuario_convocatoria', 'usuario.id_usuario = usuario_convocatoria.id_usuario', 'left');                
        $this->db->join('smca_usuarios_seguimiento', 'usuario.id_usuario = smca_usuarios_seguimiento.id_usuario', 'left');        
        $this->db->where('usuario_convocatoria.doc_estado = 1 ');
        $this->db->where('usuario_convocatoria.contrato = 1 ');
        $this->db->where('usuario_convocatoria.id_conv_insc = '.$id_conv_insc);                       
        $this->db->order_by('nota', 'DESC');
        $query=$this->db->get();
	return $query->result(); 
    }
     
    function consulta_usuario_rol_ciudad_admin($id_conv_insc) {
        $this->db->select('usuario.id_usuario, usuario.nombres, usuario.apellidos, usuario.tipo_iden, usuario.nume_iden, usuario.fecha_naci, usuario.sexo, usuario.celular, usuario.telefono, usuario.id_avatar, usuario.id_docIden, smca_usuarios_seguimiento.nota, usuario_convocatoria.contrato ');
        $this->db->from('usuario');
        $this->db->join('usuario_convocatoria', 'usuario.id_usuario = usuario_convocatoria.id_usuario', 'left');                
        $this->db->join('smca_usuarios_seguimiento', 'usuario.id_usuario = smca_usuarios_seguimiento.id_usuario', 'left');        
        $this->db->where('usuario_convocatoria.doc_estado = 1 ');        
        $this->db->where('usuario_convocatoria.id_conv_insc = '.$id_conv_insc);                       
        $this->db->order_by('nota', 'DESC');
        $query=$this->db->get();
	return $query->result(); 
    }
    
    function consulta_elegibles_rol_ciudad_admin($id_conv_insc) {
        $this->db->select('usuario.id_usuario, usuario.nombres, usuario.apellidos, usuario.tipo_iden, usuario.nume_iden, usuario.fecha_naci, usuario.sexo, usuario.celular, usuario.telefono, usuario.id_avatar, usuario.id_docIden, smca_usuarios_seguimiento.nota, usuario_convocatoria.contrato ');
        $this->db->from('usuario');
        $this->db->join('usuario_convocatoria', 'usuario.id_usuario = usuario_convocatoria.id_usuario', 'left');                
        $this->db->join('smca_usuarios_seguimiento', 'usuario.id_usuario = smca_usuarios_seguimiento.id_usuario', 'left');        
        $this->db->where('usuario_convocatoria.doc_estado = 1 ');
        $this->db->where('usuario_convocatoria.contrato = 2 ');
        $this->db->where('usuario_convocatoria.id_conv_insc = '.$id_conv_insc);                       
        $this->db->order_by('nota', 'DESC');
        $query=$this->db->get();
	return $query->result(); 
    }
    
      public function usuariosContrato($contrato){
         
        $data = array(
            'observacionesCont' => $contrato['observacionesCont'],
            'id_docCont' => $contrato['id_docCont'],
            'fecha_contratado' => $contrato['fecha_contratado'],
            'id_usuario_operador' => $contrato['id_usuario_operador'],
            'contrato' => $contrato['contrato']
        );
        $this->db->where('id_conv_insc', $contrato['id_conv_insc']);
        $this->db->where('id_usuario', $contrato['id_usuario']);
        return $this->db->update('usuario_convocatoria', $data);
         
     } 
    
     public function activaCandidato($id_conv_insc, $id_usuario){
         
        $data = array(            
            'contrato' => 1
        );
        $this->db->where('id_conv_insc', $id_conv_insc);
        $this->db->where('id_usuario', $id_usuario);
        return $this->db->update('usuario_convocatoria', $data);
         
     } 
     
    
}
