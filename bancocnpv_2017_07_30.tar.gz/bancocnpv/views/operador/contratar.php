<?php
$retornoExito = $this->session->flashdata('retornoExito');
if ($retornoExito) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
        <?php echo "<center><h4>".$retornoExito."</h4></center>"; ?>   
    </div>
    <?php
}

$retornoError = $this->session->flashdata('retornoError');
if ($retornoError) {
    ?>
    <div class="alert alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <?php echo "<center><h4>".$retornoError."</h4></center>"; ?> 
    </div>
    <?php
}
    ?>


<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<center>
			<h2></h2>
		</center>		
	</div>
</div>



                            <div class="section" >
    <div class="container">


        <div class="col-md-6 col-md-offset-3">

            <div class="row " style="background-color: white; opacity: 0.9; z-index: 10000;">
                <div class="row col-sm-12 text-center" style="background-color: #A1134D; opacity: 0.9; z-index: 10000;border-radius: 50px;">
                    <h3 style="color: #FFFFFF">Contratar Usuario: <?php echo strtoupper(utf8_decode($usuario[0]->nombres)).' '.strtoupper(utf8_decode($usuario[0]->apellidos)); ?></h3>
                </div><br><br><br>

                <div class="col-md-12">
                    <form class="form-horizontal" role="form" id="formCrearUsuario" action="<?php echo base_url('operador/principal/guardarContrato') ?>" name="formCrearUsuario" method="post" autocomplete="off" enctype="multipart/form-data">
                        <br>
                        <div style="border: solid #A1134D; padding: 3px; border-radius: 3px;  clear: both;z-index: 10000;">
                         
                            <input  type="hidden" name="id_conv_insc" id="id_conv_insc" value="<?php echo $id_conv_insc; ?> ">
                             <input  type="hidden" name="id_usuario" id="id_usuario" value="<?php echo $id_usuario; ?> ">
                            
                            <div class="form-group has-feedback">
                                <div class="col-sm-6 text-right">
                                    <label class="control-label">Contratado:</label>
                                    <br>
                                    <input class="validate[required]" type="radio" name="contratado" id="contratado" value="Si">   Si
                                    <input class="validate[required]" type="radio" name="contratado" id="contratado" value="No">   No
                                </div>	
                            </div>  
                            <div class="form-group has-feedback">
                                
                                 <div class="col-sm-12 text-left">
                                    <label for="salones" class="control-label">Observaciones:</label>
                                    <textarea id="observaciones" name="observaciones" rows="5" cols="55" class="form-control validate[required,minSize[20]]" ></textarea>
                                   
                                </div>    
                                
                                
                            </div>  
                            <div id="div_contrato" name="div_contrato">
                                <div class="form-group has-feedback">                                
                                     <div class="col-md-12">
                                          <label for="contrato" class="control-label">Contrato:</label>
                                        <input id="contrato" name="contrato" class="file  file-loading validate[required]" type="file" data-show-upload="false" data-show-caption="true" data-show-preview="false" data-show-remove="false" data-allowed-file-extensions='["pdf"]' >
                                     </div>                               

                                </div>  
                            </div>
                        </div><br>                           
                      
                        <div class="form-group">
                            <div class="col-sm-8 col-sm-offset-2 text-center">
                                <button class="btn btn-success" style="background-color: #AD124B; color: #FFFFFF" type="submit"><i class="fa fa-fw fa-check"></i>Guardar</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>