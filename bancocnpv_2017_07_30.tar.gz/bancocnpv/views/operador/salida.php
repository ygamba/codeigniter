<?php
$retornoExito = $this->session->flashdata('retornoExito');
if ($retornoExito) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
        <?php echo "<center><h4>".$retornoExito."</h4></center>"; ?>   
    </div>
    <?php
}

$retornoError = $this->session->flashdata('retornoError');
if ($retornoError) {
    ?>
    <div class="alert alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <?php echo "<center><h4>".$retornoError."</h4></center>"; ?> 
    </div>
    <?php
}
    ?>


<div class="col-md-10 col-md-offset-1 text-center">
<a href="<?php echo base_url().'operador/principal/' ?>" class="btn btn-primary" >
                            Regresar
                        </a>
</div>
