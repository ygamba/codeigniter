<?php
$retornoExito = $this->session->flashdata('retornoExito');
if ($retornoExito) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
        <?php echo "<center><h4>".$retornoExito."</h4></center>"; ?>   
    </div>
    <?php
}

$retornoError = $this->session->flashdata('retornoError');
if ($retornoError) {
    ?>
    <div class="alert alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <?php echo "<center><h4>".$retornoError."</h4></center>"; ?> 
    </div>
    <?php
}

?>
<script>
$(document).ready(function() {

    $("#inputEmailConf").bind('paste', function(e) {
        e.preventDefault();
    });

});

$(document).ready(function() {

    $("#inputEmail").bind('paste', function(e) {
        e.preventDefault();
    });
});

$(document).ready(function() {

    $("#inputClaveConf").bind('paste', function(e) {
        e.preventDefault();
    });

});

$(document).ready(function() {

    $("#inputClave").bind('paste', function(e) {
        e.preventDefault();
    });
});
 
</script>

<div class="section" >
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
        	<div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
        		<p><center><h1 style="color: #FFFFFF">REGISTRO USUARIO CNPV</h1></center></p>
        	</div>
            <div class="row" style="background-color: white; opacity: 0.9; z-index: 10000;">
                <div class="col-md-12">
                    <form class="form-horizontal" role="form" id="formCrearUsuario" action="<?php echo base_url('coordinador/principal/guardarUsuario') ?>" name="formCrearUsuario" method="post" autocomplete="off">
                        <div class="form-group has-feedback">
                            <div class="col-sm-12 text-left">
                                <label for="inputTipoIden" class="control-label">Tipo identificaci&oacute;n:</label>
                                <select class="validate[required] form-control select2-select" id="tipo_iden" name="tipo_iden"> 
                                    <option value=''>Seleccione...</option>
                                    <option value='CC'>C&eacute;dula de Ciudadan&iacute;a</option>
                                    <option value='CE'>C&eacute;dula de Extranjer&iacute;a</option>
                                    <option value='PB'>Pasaporte</option>                                
                                </select>
                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="inputNombres" class="control-label">N&uacute;mero identificaci&oacute;n:</label>
                                <input type="text" class="validate[required, custom[onlyNumberSp], minSize[4],equals[inputNumeIdenConf]] form-control" id="inputNumeIden" name="inputNumeIden" placeholder="N&uacute;mero de identificaci&oacute;n">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="inputNombres" class="control-label">Confirmar N&uacute;mero identificaci&oacute;n:</label>
                                <input type="text" class="validate[required, custom[onlyNumberSp], minSize[4],equals[inputNumeIden]] form-control" id="inputNumeIdenConf" name="inputNumeIdenConf" placeholder="N&uacute;mero de identificaci&oacute;n">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                        </div>
                        <div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label for="inputNombres" class="control-label">Nombres:</label>
                                <input type="text" class="validate[required, custom[onlyLetterSp]] form-control" id="inputNombres" name="inputNombres" placeholder="Nombres">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="inputApellidos" class="control-label">Apellidos:</label>
                                <input type="text" class="validate[required, custom[onlyLetterSp]] form-control" id="inputApellidos" name="inputApellidos" placeholder="Apellidos">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                        </div>
                        <div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label for="inputEmail" class="control-label">Correo electr&oacute;nico:</label>
                                <input type="text" class="validate[custom[email],equals[inputEmailConf]] form-control" id="inputEmail" name="inputEmail" placeholder="Correo electr&oacute;nico">
                                
                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="inputEmail" class="control-label">Confirmar correo electr&oacute;nico:</label>
                                <input type="text" class="validate[custom[email],equals[inputEmail]] form-control" id="inputEmailConf" name="inputEmailConf" placeholder="Confirmar correo electr&oacute;nico">
                                
                            </div>
                        </div>
                        <div class="form-group has-feedback">
	                        <div class="col-sm-6 text-left">
	                                <label for="inputNombres" class="control-label">Celular:</label>
	                                <input type="text" class="validate[required, custom[onlyNumberSp], minSize[10],equals[celularConf]] form-control" id="celular" name="celular" placeholder="N&uacute;mero de celular"> 
	                                <span class="fa fa-check form-control-feedback"></span>
	                        </div>
	                        <div class="col-sm-6 text-left">
	                                <label for="inputNombres" class="control-label">Confirmar Celular:</label>
	                                <input type="text" class="validate[required, custom[onlyNumberSp], minSize[10],equals[celular]] form-control" id="celularConf" name="celularConf" placeholder="Confirmar N&uacute;mero de celular">
	                                <span class="fa fa-check form-control-feedback"></span>
	                        </div>
                        </div>
                        <div class="form-group has-feedback">
                        	<div class="col-sm-6 text-left">
                                <label class="control-label">Departamento de residencia:</label>
                                <select id="departamento" name="departamento" class="select2" style="width: 250px;">
				                    <option value=""></option>
									<?php
									for ($i = 0; $i < count($departamentos); $i++) {
									    echo "<option value='" . $departamentos[$i]->id_depto . "'>" . utf8_decode($departamentos[$i]->nom_depto) . "</option>";
									}
									?>
								</select>
                            </div>
                            <div class="col-sm-6">
								<label class="control-label" for="municipio">Municipio</label>
								<select id="municipio" name="municipio" class="form-control validate[required]">
								  <option value="">Seleccione...</option>
								  <?php
									for($a=0;$a<count($municipio);$a++)
									{
										echo "<option value='".$municipio[$a]->id_areacono."'>".utf8_decode($municipio[$a]->desc_areacono)."</option>";
									}
								  ?>
								</select>
							</div>
						</div>
						<div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label for="inputNombres" class="control-label">Telefono Fijo:</label>
                                <input type="text" class="validate[custom[onlyNumberSp], minSize[7]] form-control" id="telefono" name="telefono" placeholder="N&uacute;mero de telefono">
                            </div>
                            <div class="col-sm-6 text-left">
	                            <label class="control-label">Sexo:</label>
	                            <br>
	                            <input class="validate[required]" type="radio" name="sexo" id="sexo" value="F">   Mujer
	                            <input class="validate[required]" type="radio" name="sexo" id="sexo" value="M">   Hombre
	                        </div>	
                        </div>
                        <div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label class="control-label">Fecha de nacimiento:</label>
                                <div class="input-group input-append date" id="datePicker">
                                    <input type="text" class="form-control validate[required]" name="fechaNaciMov" id="fechaNaciMov" data-date-end-date="-18y"/>
                                    <span class="input-group-addon add-on"><span class="glyphicon glyphicon-calendar"></span></span>
                                </div>
                            </div>
                            <div class="col-sm-6 text-left">
                                <label class="control-label">Fecha de expedici&oacute;n:</label>
                                <div class="input-group input-append date" id="datePicker">
                                    <input type="text" class="form-control validate[required]" name="fechaExpMov" id="fechaExpMov" data-date-end-date="-18y"/>
                                    <span class="input-group-addon add-on"><span class="glyphicon glyphicon-calendar"></span></span>
                                </div>
                            </div>
                        </div>
						</div>
						</div>
                        <div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
			        		<p><center><h1 style="color: #FFFFFF">FORMACION ACADEMICA</h1></center></p>
			        	</div>
						<div class="row" style="background-color: white; opacity: 0.9; z-index: 10000;">
						<div class="col-md-12">
						<div class="panel-body" id="divNuevoFormacion">
							<div class="row" id="div_formacion_ext">
					        	<div class="col-sm-6 text-left">
					        		<label class="control-label">Nivel de estudios:</label>
		                            <select id="nivel-1" name="nivel[]" class="validate[required] form-control" style="width: 250px;">
				                    	<option value=""></option>
										<?php
										for ($i = 0; $i < count($programa); $i++) {
										    echo "<option value='" . $programa[$i]->id_nivel . "'>" . utf8_decode($programa[$i]->descripcion) . "</option>";
										}
										?>
									</select>
		                        </div>
		                        <div class="col-sm-6 text-left">
		                        	<label class="control-label" for="nivel">Semestres o cursos aprobados</label>
									<select id="semestres-1" name="semestres[]" class="form-control validate[required]">
									  <option value="">Seleccione...</option>
									  <?php
										for($ns=1;$ns <= 11;$ns++)
										{
											echo "<option value='".$ns."'>".$ns."</option>";
										}
									  ?>
									</select>
		                        </div>
	                        </div>
                        </div>
                        <div class="panel-footer">
	                        <div class="row">
	                            <div class="col-sm-12">
	                            	<input type="hidden" name="tam" id="tamForm" value="1" >
	                                <div class="btn btn-info" id="btnAgregarForm"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>  Agregar </div>
	                                <div class="btn btn-warning" id="btnBorrarForm"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span>  Quitar </div>
	                            </div>
	                        </div>
	                    </div>
						</div>
						</div>
						
						<div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
			        		<p><center><h1 style="color: #FFFFFF">EXPERIENCIA LABORAL</h1></center></p>
			        	</div>
						<div class="row" style="background-color: white; opacity: 0.9; z-index: 10000;">
						<div class="col-md-12">
						<div class="panel-body" id="divNuevoExp">
							<div class="row" id="div_exp_ext">    
								<div class="col-sm-4">
									<label class="control-label" for="empresa">Empesa</label>
									<input type="text" id="empresa-1" name="empresa[]" class="form-control validate[required]">
								</div>
								<div class="col-sm-4">
									<label class="control-label" for="areas">Fecha Inicial</label>
									<input type="text" id="fechaInicial-1" name="fechaInicial[]" class="form-control validate[required]" placeholder="DD-MM-YYYY">
								</div>
								<div class="col-sm-4">
									<label class="control-label" for="nivel">Fecha final</label>
									<input type="text" id="fechaFinal-1" name="fechaFinal[]" class="form-control validate[required]" placeholder="DD-MM-YYYY">
								</div>	                            
							</div>
						</div>
						<div class="panel-footer">
	                        <div class="row">
	                            <div class="col-sm-12">
	                            	<input type="hidden" name="tam" id="tamExp" value="0" >
	                                <div class="btn btn-info" id="btnAgregarExp"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>  Agregar </div>
	                                <div class="btn btn-warning" id="btnBorrarExp"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span>  Quitar </div>
	                            </div>
	                        </div>
	                    </div>
						</div>
						</div>
						
						
						<div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
			        		<p><center><h1 style="color: #FFFFFF">CONVOCATORIA A PARTICIPAR</h1></center></p>
			        	</div>
						<div class="row" style="background-color: white; opacity: 0.9; z-index: 10000;">
						<div class="col-md-12">
								<div class="col-sm-4">
									<label class="control-label" for="departamentoAplica">Departamento</label>
									<select id="departamentoAplica" name="departamentoAplica" class="form-control validate[required]">
									  <option value="">Seleccione...</option>
									  <?php
										for($n=0;$n<count($departamentos);$n++)
										{
											echo "<option value='".$departamentos[$n]->id_depto."'>".utf8_decode($departamentos[$n]->nom_depto)."</option>";
										}
									  ?>
									</select>
								</div>
								<div class="col-sm-4">
									<label class="control-label" for="municipioAplica">Municipio</label>
									<select id="municipioAplica" name="municipioAplica" class="form-control validate[required]">
									  <option value="">Seleccione...</option>
									  <?php
										for($a=0;$a<count($municipio);$a++)
										{
											echo "<option value='".$municipio[$a]->id_areacono."'>".utf8_decode($municipio[$a]->desc_areacono)."</option>";
										}
									  ?>
									</select>
								</div>
								<div class="col-sm-4">
									<label class="control-label" for="rolAplica">Rol</label>
									<select id="rolAplica" name="rolAplica" class="form-control validate[required]">
									  <option value="">Seleccione...</option>
									  <?php
										for($n=0;$n<count($roles);$n++)
										{
											echo "<option value='".$roles[$n]->id_rol_inv."'>".utf8_decode($roles[$n]->nombre_rol_inv)."</option>";
										}
									  ?>
									</select>
								</div>	                            
							</div>
						</div>
						
                        <div class="form-group">
                            <div class="col-sm-8 col-sm-offset-2 text-center">
                                <button class="btn btn-success" style="background-color: #AD124B; color: #FFFFFF" type="submit"><i class="fa fa-fw fa-check"></i>Guardar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
