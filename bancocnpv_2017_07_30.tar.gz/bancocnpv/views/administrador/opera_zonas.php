<?php

$retornoExito = $this->session->flashdata('retornoExito');
if ($retornoExito) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
        <?php echo $retornoExito ?>
    </div>
    <?php
}

$retornoError = $this->session->flashdata('retornoError');
if ($retornoError) {
    ?>
    <div class="alert alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <?php echo $retornoError ?>
    </div>
    <?php
}

?>


<div class="section" style="background-size: 100% 100%; background-repeat: no-repeat;">
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
        	<div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
        		<p><center><h1 style="color: #FFFFFF">REGISTRO DE ZONAS POR OPERADOR</h1></center></p>
        	</div>
            <div class="row" style="background-color: white; opacity: 0.9; z-index: 10000;">
                <div class="col-md-12">
                    <form class="form-horizontal" role="form" id="formCrearUsuario" action="<?php echo base_url('administrador/operador/guardarZonas') ?>" name="formCrearUsuario" method="post" autocomplete="off">
                       <div class="col-md-10 col-md-offset-1 text-center">
                                                                                                 
                                <label class="control-label">Operadores</label><br>
                                <select id="operador" name="operador"   class="form-control validate[required]">
                                    <option value="">Seleccione un Operador</option>
                                    <?php
                                    for ($j = 0; $j < count($operadores); $j++) {
                                        echo "<option value='" . $operadores[$j]->id_operador . "'>" . utf8_decode($operadores[$j]->nombre) . "</option>";    
                                    }
                                    ?>
                                </select>
                        </div>
                       <br><br>
                        
                        <div class="form-group" id="div_ciudad">
                                <div class="col-md-12">
                                    <label class="control-label" for="nivel">Ciudad o ciudades a asignar</label>
                                    <select id="ciudades" name="ciudades[]" multiple="multiple" class="form-control validate[funcCall[ifSelectNotEmpty]]">
                                        <?php
                                         for ($c = 0; $c < count($ciudades); $c++) {
                                                    echo "<option value='" . $ciudades[$c]->id_mpio . "' data-section='" . utf8_decode($ciudades[$c]->nomb_terri) . "'>" . utf8_decode($ciudades[$c]->nom_mpio) . "</option>";                                           
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>		
                                                
                        <div class="form-group">
                            <div class="col-sm-8 col-sm-offset-2 text-center">
                                <button class="btn btn-success" style="background-color: #AD124B; color: #FFFFFF" type="submit"><i class="fa fa-fw fa-check"></i>Asignar</button>
                            </div>
                        </div> 
                    </form>
                </div>
            </div>
             <br>
            <div class="panel panel-default">
                <div class="panel-heading text-right">
                    <div class="nav">				
                        <div class="btn-group pull-left" data-toggle="buttons">
                            <label>
                                Operadores por ciudad Actuales
                            </label>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
					<table class="table table-striped" id="tablaOpera">
						<thead>
							<tr>
								<th>ID</th>								
                                                                <th>Ciudad</th>
                                                                <th>Operador</th>
                                                                <th>Editar</th>
							</tr>
						</thead>
						<tbody>
						<?php
						
						for ($i = 0; $i < count($ciudadesya); $i++) {  
							?>
							<tr>
							<td><?php echo utf8_decode($ciudadesya[$i]->id_zon_oper)?></td>							
                                                        <td><?php echo utf8_decode($ciudadesya[$i]->nom_mpio)?></td>
                                                        <td><?php echo utf8_decode($ciudadesya[$i]->nombre)?></td>
                                                        <td>
                                                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#crearOperador<?php echo $ciudadesya[$i]->id_zon_oper ?>">
                                                                            Editar Operador
                                                            </a>

                                                                    <div class="modal fade bs-example-modal-lg" id="crearOperador<?php echo $ciudadesya[$i]->id_zon_oper ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                                                        <div class="modal-dialog modal-lg" role="document">
                                                                            <div class="modal-content">
                                                                                <form class="form-horizontal" role="form" id="formExpCoor" action="<?php echo base_url('administrador/operador/editarCiudadO/'.$ciudadesya[$i]->id_zon_oper); ?>" name="formExpCoor" method="post">
                                                                                    <div class="modal-header">
                                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                                                        <h4 class="modal-title" id="myModalLabel">Creaci&oacute;n del Operador</h4>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="row">
                                                                                            <div class="col-md-10 col-md-offset-1 text-center">
                                                                                                 
                                                                                                    <label class="control-label">Operador Asignado a la ciudad de  : <?php echo utf8_decode($ciudadesya[$i]->nom_mpio)?></label><br>
                                                                                                    <select id="operador" name="operador"   class="form-control validate[required]">
                                                                                                        <option value=""></option>
                                                                                                        <?php
                                                                                                        for ($j = 0; $j < count($operadores); $j++) {
                                                                                                            
                                                                                                            if($ciudadesya[$i]->id_operador == $operadores[$j]->id_operador){
                                                                                                            echo "<option value='" . $operadores[$j]->id_operador . "' selected >" . utf8_decode($operadores[$j]->nombre) . "</option>" ;    
                                                                                                            }else{
                                                                                                            echo "<option value='" . $operadores[$j]->id_operador . "'>" . utf8_decode($operadores[$j]->nombre) . "</option>";    
                                                                                                            }
                                                                                                            
                                                                                                        }
                                                                                                        ?>
                                                                                                    </select>
                                                                                            </div>								  			
                                                                                        </div>                                        
                                                                                    </div>
                                                                                    <div class="modal-footer">
                                                                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                                                                        <button type="submit" class="btn btn-success">Actualizar</button>
                                                                                    </div>	
                                                                                </form>	
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            
                                                            
                                                            
                                                        </td>
							</tr>
						<?php	
						}
						?>
						</tbody>
					</table>
				</div>
			</div>
             <br><br>
            <div class="col-md-10 col-md-offset-1 text-center">
            <a href="<?php echo base_url('administrador/operador')?>" class="btn btn-success"> Regresar </a>
            </div><br><br> 
        </div>
    </div>
</div>
