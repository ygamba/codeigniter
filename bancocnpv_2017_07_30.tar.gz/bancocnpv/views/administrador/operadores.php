<?php

$retornoExito = $this->session->flashdata('retornoExito');
if ($retornoExito) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
        <?php echo $retornoExito ?>
    </div>
    <?php
}

$retornoError = $this->session->flashdata('retornoError');
if ($retornoError) {
    ?>
    <div class="alert alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <?php echo $retornoError ?>
    </div>
    <?php
}

?>


<div class="section" style="background-size: 100% 100%; background-repeat: no-repeat;">
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
        	<div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
        		<p><center><h1 style="color: #FFFFFF">REGISTRO OPERADORES</h1></center></p>
        	</div>
              
            <br>            
          
            <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#crearOperador">
                            Crear Operador
            </a>
 
                    <div class="modal fade bs-example-modal-lg" id="crearOperador" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <form class="form-horizontal" role="form" id="formExpCoor" action="<?php echo base_url('administrador/operador/guardarOperadorP'); ?>" name="formExpCoor" method="post">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title" id="myModalLabel">Creaci&oacute;n del Operador</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-10 col-md-offset-1 text-center">
                                                  <label >Nombre Operador</label> 
                                                     <input type="text" id="operador" class="form-control validate[required]" name="operador"  >
                                            </div>								  			
                                        </div>                                        
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                        <button type="submit" class="btn btn-success">Crear</button>
                                    </div>	
                                </form>	
                            </div>
                        </div>
                    </div>
            
            <br><br>
            

<div class="panel panel-default">
                <div class="panel-heading text-right">
                    <div class="nav">				
                        <div class="btn-group pull-left" data-toggle="buttons">
                            <label>
                                Operadores Actuales
                            </label>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
					<table class="table table-striped" id="tablaOpera">
						<thead>
							<tr>
								<th>ID</th>
								<th>Operador</th>
                                                                <th>Editar</th>
							</tr>
						</thead>
						<tbody>
						<?php
						
						for ($i = 0; $i < count($operadores); $i++) {  
							?>
							<tr>
							<td><?php echo utf8_decode($operadores[$i]->id_operador)?></td>
							<td><?php echo utf8_decode($operadores[$i]->nombre)?></td>
                                                        <td>
                                                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#crearOperador<?php echo $operadores[$i]->id_operador ?>">
                                                                            Editar Operador
                                                            </a>

                                                                    <div class="modal fade bs-example-modal-lg" id="crearOperador<?php echo $operadores[$i]->id_operador ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                                                        <div class="modal-dialog modal-lg" role="document">
                                                                            <div class="modal-content">
                                                                                <form class="form-horizontal" role="form" id="formExpCoor" action="<?php echo base_url('administrador/operador/editarOperadorP/'.$operadores[$i]->id_operador); ?>" name="formExpCoor" method="post">
                                                                                    <div class="modal-header">
                                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                                                        <h4 class="modal-title" id="myModalLabel">Creaci&oacute;n del Operador</h4>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="row">
                                                                                            <div class="col-md-10 col-md-offset-1 text-center">
                                                                                                  <label >Nombre Operador</label> 
                                                                                                  <input type="text" id="operador" class="form-control validate[required]" name="operador"  value="<?php echo utf8_decode($operadores[$i]->nombre)?>">
                                                                                            </div>								  			
                                                                                        </div>                                        
                                                                                    </div>
                                                                                    <div class="modal-footer">
                                                                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                                                                        <button type="submit" class="btn btn-success">Actualizar</button>
                                                                                    </div>	
                                                                                </form>	
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            
                                                            
                                                            
                                                        </td>
							</tr>
						<?php	
						}
						?>
						</tbody>
					</table>
				</div>
			</div>
<br>
            
            <div class="col-md-10 col-md-offset-1 text-center">
            <a href="<?php echo base_url('administrador/operador')?>" class="btn btn-success"> Regresar </a>
            </div><br><br>
        </div>
    </div>
</div>



