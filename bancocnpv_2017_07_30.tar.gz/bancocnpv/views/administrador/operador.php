<?php

$retornoExito = $this->session->flashdata('retornoExito');
if ($retornoExito) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
        <?php echo $retornoExito ?>
    </div>
    <?php
}

$retornoError = $this->session->flashdata('retornoError');
if ($retornoError) {
    ?>
    <div class="alert alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <?php echo $retornoError ?>
    </div>
    <?php
}

?>


<div class="section" style="background-size: 100% 100%; background-repeat: no-repeat;">
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
        	<div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
        		<p><center><h1 style="color: #FFFFFF">REGISTRO USUARIOS OPERADOR CONTRATACI&Oacute;N</h1></center></p>
        	</div>
            <div class="row" style="background-color: white; opacity: 0.9; z-index: 10000;">
                <div class="col-md-12">
                    <form class="form-horizontal" role="form" id="formCrearUsuario" action="<?php echo base_url('administrador/operador/guardarUsuarioOperador') ?>" name="formCrearUsuario" method="post" autocomplete="off">
                        <div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label for="inputTipoIden" class="control-label">Tipo identificaci&oacute;n:</label>
                                <select class="validate[required] form-control select2-select" id="tipo_iden" name="tipo_iden"> 
                                    <option value=''>Seleccione...</option>
                                    <option value='CC'>C&eacute;dula de Ciudadan&iacute;a</option>
                                    <option value='CE'>C&eacute;dula de Extranjer&iacute;a</option>
                                    <option value='PB'>Pasaporte</option>                                
                                </select>
                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="inputNombres" class="control-label">N&uacute;mero identificaci&oacute;n:</label>
                                <input type="text" class="validate[required, custom[onlyNumberSp], minSize[4]] form-control" id="inputNumeIden" name="inputNumeIden" placeholder="N&uacute;mero de identificaci&oacute;n">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                        </div>
                        <div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label for="inputNombres" class="control-label">Nombres:</label>
                                <input type="text" class="validate[required, custom[onlyLetterSp]] form-control" id="inputNombres" name="inputNombres" placeholder="Nombres">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="inputApellidos" class="control-label">Apellidos:</label>
                                <input type="text" class="validate[required, custom[onlyLetterSp]] form-control" id="inputApellidos" name="inputApellidos" placeholder="Apellidos">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                        </div>
                        <div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label for="inputEmail" class="control-label">Correo electr&oacute;nico:</label>
                                <input type="text" class="validate[required, custom[email]] form-control" id="inputEmail" name="inputEmail" placeholder="Correo electr&oacute;nico">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                            <div class="col-sm-6 text-left">
	                                <label for="inputNombres" class="control-label">Celular:</label>
	                                <input type="text" class="validate[required, custom[onlyNumberSp], minSize[10]] form-control" id="celular" name="celular" placeholder="N&uacute;mero de celular">
	                                <span class="fa fa-check form-control-feedback"></span>
	                        </div>
                        </div>
                        
                        <div class="form-group has-feedback">
                                <div class="col-sm-6 text-left">
                                    <label class="control-label">Operador al que Pertenece:</label>
                                    <select id="operador" name="operador"   class="form-control validate[required]">
                                        <option value=""></option>
                                        <?php
                                        for ($i = 0; $i < count($operadores); $i++) {
                                            echo "<option value='" . $operadores[$i]->id_operador . "'>" . utf8_decode($operadores[$i]->nombre) . "</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                
                            </div>
                        
                        
                        <div class="form-group">
                            <div class="col-sm-8 col-sm-offset-2 text-center">
                                <button class="btn btn-success" style="background-color: #AD124B; color: #FFFFFF" type="submit"><i class="fa fa-fw fa-check"></i>Registrarse</button>
                            </div>
                        </div> 
                    </form>
                </div>
            </div>
            
            <div class="panel panel-default">
                <div class="panel-heading text-right">
                    <div class="nav">				
                        <div class="btn-group pull-left" data-toggle="buttons">
                            <label>
                                Usuarios Operadores Actuales
                            </label>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
					<table class="table table-striped display nowrap" id="tablaOpera">
						<thead>
							<tr>
								<th>ID</th>
								<th>Usuario Operador</th>
                                                                <th>Operador</th>
                                                                <th>Editar Usuario Operador</th>
                                                                
							</tr>
						</thead>
						<tbody>
						<?php
						
						for ($i = 0; $i < count($operadorc); $i++) {  
							?>
							<tr>
							<td><?php echo utf8_decode($operadorc[$i]->id_usuario)?></td>
							<td><?php echo utf8_decode($operadorc[$i]->nombres).' '.utf8_decode($operadorc[$i]->apellidos)?></td>
                                                        <td><?php echo utf8_decode($operadorc[$i]->nombre)?></td>
                                                        <td>
                                                            <a href="#" class="btn btn-warning" data-toggle="modal" data-target="#crearOperador<?php echo $operadorc[$i]->id_usuario ?>">
                                                                            Editar Operador
                                                            </a>

                                                                    <div class="modal fade bs-example-modal-lg" id="crearOperador<?php echo $operadorc[$i]->id_usuario ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                                                        <div class="modal-dialog modal-lg" role="document">
                                                                            <div class="modal-content">
                                                                                <form class="form-horizontal" role="form" id="formExpCoor" action="<?php echo base_url('administrador/operador/editarUsuarioOp/'.$operadorc[$i]->id_usuario); ?>" name="formExpCoor" method="post">
                                                                                    <div class="modal-header">
                                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                                                        <h4 class="modal-title" id="myModalLabel">Creaci&oacute;n del Operador</h4>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="row">
                                                                                            <div class="col-md-10 col-md-offset-1 text-center">
                                                                                                 
                                                                                                    <label class="control-label">Operador al que Pertenece el Usuario : <?php echo utf8_decode($operadorc[$i]->nombres).' '.utf8_decode($operadorc[$i]->apellidos)?></label><br>
                                                                                                    <select id="operador" name="operador"   class="form-control validate[required]">
                                                                                                        <option value=""></option>
                                                                                                        <?php
                                                                                                        for ($j = 0; $j < count($operadores); $j++) {
                                                                                                            
                                                                                                            if($operadorc[$i]->id_operador == $operadores[$j]->id_operador){
                                                                                                            echo "<option value='" . $operadores[$j]->id_operador . "' selected >" . utf8_decode($operadores[$j]->nombre) . "</option>" ;    
                                                                                                            }else{
                                                                                                            echo "<option value='" . $operadores[$j]->id_operador . "'>" . utf8_decode($operadores[$j]->nombre) . "</option>";    
                                                                                                            }
                                                                                                            
                                                                                                        }
                                                                                                        ?>
                                                                                                    </select>
                                                                                            </div>								  			
                                                                                        </div>                                        
                                                                                    </div>
                                                                                    <div class="modal-footer">
                                                                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                                                                                        <button type="submit" class="btn btn-success">Actualizar</button>
                                                                                    </div>	
                                                                                </form>	
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            
                                                            
                                                            
                                                        </td>
							</tr>
						<?php	
						}
						?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
            <br>
            
            <div class="col-md-10 col-md-offset-1 text-center">
            <a href="<?php echo base_url('administrador/operador')?>" class="btn btn-success"> Regresar </a>
            </div><br><br>      
        </div>
    </div>
</div>
