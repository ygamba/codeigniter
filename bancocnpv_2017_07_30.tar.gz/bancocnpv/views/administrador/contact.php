<?php

$retornoExito = $this->session->flashdata('retornoExito');
if ($retornoExito) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
        <?php echo $retornoExito ?>
    </div>
    <?php
}

$retornoError = $this->session->flashdata('retornoError');
if ($retornoError) {
    ?>
    <div class="alert alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <?php echo $retornoError ?>
    </div>
    <?php
}

?>


<div class="section" style="background-size: 100% 100%; background-repeat: no-repeat;">
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
        	<div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
        		<p><center><h1 style="color: #FFFFFF">REGISTRO USUARIOS CONTACT CENTER</h1></center></p>
        	</div>
            <div class="row" style="background-color: white; opacity: 0.9; z-index: 10000;">
                <div class="col-md-12">
                    <form class="form-horizontal" role="form" id="formCrearUsuario" action="<?php echo base_url('administrador/contact/guardarContact') ?>" name="formCrearUsuario" method="post" autocomplete="off">
                        <div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label for="inputTipoIden" class="control-label">Tipo identificaci&oacute;n:</label>
                                <select class="validate[required] form-control select2-select" id="tipo_iden" name="tipo_iden"> 
                                    <option value=''>Seleccione...</option>
                                    <option value='CC'>C&eacute;dula de Ciudadan&iacute;a</option>
                                    <option value='CE'>C&eacute;dula de Extranjer&iacute;a</option>
                                    <option value='PB'>Pasaporte</option>                                
                                </select>
                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="inputNombres" class="control-label">N&uacute;mero identificaci&oacute;n:</label>
                                <input type="text" class="validate[required, custom[onlyNumberSp], minSize[4]] form-control" id="inputNumeIden" name="inputNumeIden" placeholder="N&uacute;mero de identificaci&oacute;n">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                        </div>
                        <div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label for="inputNombres" class="control-label">Nombres:</label>
                                <input type="text" class="validate[required, custom[onlyLetterSp]] form-control" id="inputNombres" name="inputNombres" placeholder="Nombres">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="inputApellidos" class="control-label">Apellidos:</label>
                                <input type="text" class="validate[required, custom[onlyLetterSp]] form-control" id="inputApellidos" name="inputApellidos" placeholder="Apellidos">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                        </div>
                        <div class="form-group has-feedback">
                            <div class="col-sm-6 text-left">
                                <label for="inputEmail" class="control-label">Correo electr&oacute;nico:</label>
                                <input type="text" class="validate[required, custom[email]] form-control" id="inputEmail" name="inputEmail" placeholder="Correo electr&oacute;nico">
                                <span class="fa fa-check form-control-feedback"></span>
                            </div>
                            <div class="col-sm-6 text-left">
	                                <label for="inputNombres" class="control-label">Celular:</label>
	                                <input type="text" class="validate[required, custom[onlyNumberSp], minSize[10]] form-control" id="celular" name="celular" placeholder="N&uacute;mero de celular">
	                                <span class="fa fa-check form-control-feedback"></span>
	                        </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-8 col-sm-offset-2 text-center">
                                <button class="btn btn-success" style="background-color: #AD124B; color: #FFFFFF" type="submit"><i class="fa fa-fw fa-check"></i>Registrarse</button>
                            </div>
                        </div> 
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
