<?php

$retornoExito = $this->session->flashdata('retornoExito');
if ($retornoExito) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
        <?php echo $retornoExito ?>
    </div>
    <?php
}

$retornoError = $this->session->flashdata('retornoError');
if ($retornoError) {
    ?>
    <div class="alert alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <?php echo $retornoError ?>
    </div>
    <?php
}

?>


<div class="section" style="background-size: 100% 100%; background-repeat: no-repeat;">
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
        	<div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
        		<p><center><h1 style="color: #FFFFFF">OPERACIONES A REALIZAR</h1></center></p>
        	</div><br>
            <div class="row" style="background-color: white; opacity: 0.9; z-index: 10000;">
                <div class="col-md-12">
                
                            <div class="col-sm-6 text-center">
                                  <a href="<?php echo base_url('administrador/operador/operadores')?>" class="btn btn-primary btn-lg"> Administrar Operadores </a>
                            </div>
                    <div class="col-sm-6  text-center">
                        <a href="<?php echo base_url('administrador/operador/operadoreszonas')?>" class="btn btn-success btn-lg"> Administrar Zonas Operadores </a>        
                        
                            </div>
                    
                    
                    
                </div><br><br><br> 
                <div class="col-md-12">
                
                            
                    <div class="col-sm-6  text-center">
                        <a href="<?php echo base_url('administrador/operador/candidatos')?>" class="btn btn-warning btn-lg"> Administrar Candidatos </a>        
                        
                            </div>
                    <div class="col-sm-6  text-center">
                                <a href="<?php echo base_url('administrador/operador/operadorc')?>" class="btn btn-info btn-lg"> Administrar Usuarios Operadores </a>
                            </div>
                    
                    
                </div>   
                
                
                <br><br><br>
            </div>
        </div>
    </div>    
</div>
