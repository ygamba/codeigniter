<?php
$retornoExito = $this->session->flashdata('retornoExito');
if ($retornoExito) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
        <?php echo "<center><h4>".$retornoExito."</h4></center>"; ?>   
    </div>
    <?php
}

$retornoError = $this->session->flashdata('retornoError');
if ($retornoError) {
    ?>
    <div class="alert alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <?php echo "<center><h4>".$retornoError."</h4></center>"; ?> 
    </div>
    <?php
}

?>

<div class="section" >
    <div class="container">
        <div class="col-md-6 col-md-offset-3">
        	<div class="row" style="background-color: #A1134D; opacity: 0.9; z-index: -10000;">
        		<p><center><h1 style="color: #FFFFFF">CARGUE DE DOCUMENTO</h1></center></p>
        	</div>
            <div class="row" style="background-color: white; opacity: 0.9; z-index: 10000;">
                <div class="col-md-12">
                    <form class="form-horizontal" role="form" id="formCrearUsuario" action="<?php echo base_url('coordinador/principal/guardarUsuario') ?>" name="formCrearUsuario" method="post" autocomplete="off">
                        <div class="form-group has-feedback">
                            <div class="col-md-6" id="div_sopforma">
								<label class="control-label" for="textinput">Soporte formaci&oacuten acad&eacute;mica</label>
								<span class='glyphicon glyphicon-info-sign' aria-hidden='true' data-toggle="tooltip" data-placement="left" title="Documentos permitidos: PDF no mayor a 5Mb"></span>
								<div class="form-group">
								  <div class="col-md-12">
									<input id="doc_formacion" name="doc_formacion" class="file  file-loading" type="file" data-show-upload="false" data-show-caption="true" data-show-preview="false" data-show-remove="false" data-allowed-file-extensions='["pdf"]' >
								  </div>
								</div>
							</div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-8 col-sm-offset-2 text-center">
                                <button class="btn btn-success" style="background-color: #AD124B; color: #FFFFFF" type="submit"><i class="fa fa-fw fa-check"></i>Guardar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
