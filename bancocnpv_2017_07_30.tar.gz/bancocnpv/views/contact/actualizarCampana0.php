<?php
$errorBD = $this->session->flashdata('errorBD');
if ($errorBD) {
    ?>
    <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <strong>Error!</strong> <?php echo $errorBD ?>
    </div>
    <?php
}

$registroExitoso = $this->session->flashdata('registroExitoso');
if ($registroExitoso) {
    ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
        <strong>OK!</strong> <?php echo $registroExitoso ?>
    </div>
    <?php
}
?>
<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<center>
			<h2>ACTUALIZACI&Oacute;N DE CONTACT CENTER CAMPA&Ntilde;A 0</h2>
		</center>		
	</div>
</div>
<br>
<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<form class="form-horizontal" enctype="multipart/form-data" role="form" id="formCargaArchivo" action="<?php echo base_url('contact/principal/cargarCampana0') ?>" name="formCargaArchivo" method="post">
			  <div class="modal-body">
					<div class="col-md-10 col-md-offset-1">
						<label class="control-label" for="textinput">Seleccione el archivo excel(xls) a importar</label>
						<div class="form-group">
						  <div class="col-md-12">
							<input id="doc_campana0" name="doc_campana0" class="file file-loading validate[required]" type="file" data-show-upload="false" data-show-caption="true" data-show-preview="true" data-show-remove="false" data-allowed-file-extensions='["xls"]' >
						  </div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
						<button type="submit" class="btn btn-success" >Aceptar</button>
					  </div>
					  </form>
					</div>
			  </div>
		  </form>		
	</div>
</div>
<br>

<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="modalCargando">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
		<center>
			<img src="<?php echo base_url('assets/img/cargando.gif')?>">
		</center>    	
    </div>
  </div>
</div>
