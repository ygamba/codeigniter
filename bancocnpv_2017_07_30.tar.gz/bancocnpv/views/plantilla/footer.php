<div class="container">
	<div class="row" style="text-align: center; color: #FFFFFF">
		<!--Carrera 59 No. 26-70 Interior I - CAN C&oacute;digo postal 111321 - Apartado A&eacute;reo 80043 - Tel +571 5978300 Ext 2568 - Fax +571 5978399 - Bogot&aacute; D.C., Colombia-->
		<!-- Cualquier inquietud comunicarla al correo  banco_hojasdevida@dane.gov.co  -->
	</div>
</div>